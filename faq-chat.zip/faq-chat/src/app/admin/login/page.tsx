"use client";

import { useActionState } from "react";
import { loginAction, type ActionState } from "@/actions/auth";

export default function LoginPage() {
  const [state, formAction, pending] = useActionState<ActionState, FormData>(loginAction, undefined);

  return (
    <main className="flex flex-1 items-center justify-center px-4">
      <form action={formAction} className="w-full max-w-sm rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <h1 className="text-lg font-semibold text-slate-800">Painel Administrativo</h1>
        <p className="mt-1 text-sm text-slate-500">Entre com seu usuário e senha para gerenciar a base de FAQ.</p>

        <div className="mt-4 flex flex-col gap-3">
          <label className="text-sm text-slate-600">
            Nome de usuário
            <input
              name="username"
              autoComplete="username"
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              required
            />
          </label>
          <label className="text-sm text-slate-600">
            Senha
            <input
              type="password"
              name="password"
              autoComplete="current-password"
              className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
              required
            />
          </label>
        </div>

        {state?.error && <p className="mt-3 text-sm text-red-600">{state.error}</p>}

        <button
          type="submit"
          disabled={pending}
          className="mt-4 w-full rounded-lg bg-slate-800 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
        >
          {pending ? "Entrando..." : "Entrar"}
        </button>
      </form>
    </main>
  );
}
