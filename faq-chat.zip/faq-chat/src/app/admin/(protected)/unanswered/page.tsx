import Link from "next/link";
import { listUnanswered, type UnansweredStatus } from "@/lib/db/repositories/unanswered";
import { updateUnansweredStatusAction } from "@/actions/unanswered";

const STATUS_OPTIONS: UnansweredStatus[] = [
  "PENDENTE",
  "EM_ANALISE",
  "TRANSFORMADA",
  "DUPLICADA",
  "DESCARTADA",
  "RESOLVIDA",
];

export default async function UnansweredPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const params = await searchParams;
  const status = params.status as UnansweredStatus | undefined;
  const items = listUnanswered(status);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-lg font-semibold text-slate-800">Perguntas não respondidas</h1>
        <p className="text-sm text-slate-500">
          Dúvidas que o chat não conseguiu responder com segurança, agrupadas por texto normalizado.
        </p>
      </div>

      <form className="flex gap-2" method="get">
        <select name="status" defaultValue={status ?? ""} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
          <option value="">Todos os status</option>
          {STATUS_OPTIONS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        <button className="rounded-lg border border-slate-300 px-3 py-2 text-sm">Filtrar</button>
      </form>

      <div className="flex flex-col gap-3">
        {items.length === 0 && <p className="text-sm text-slate-400">Nenhuma pergunta nessa situação.</p>}
        {items.map((item) => (
          <div key={item.id} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-sm font-medium text-slate-800">{item.originalQuestion}</p>
                <p className="mt-1 text-xs text-slate-400">
                  {item.occurrenceCount}x • melhor score encontrado: {item.bestScoreFound.toFixed(2)} • primeira
                  ocorrência em {new Date(item.firstOccurredAt).toLocaleDateString("pt-BR")}
                </p>
              </div>
              {item.status !== "TRANSFORMADA" && (
                <Link
                  href={`/admin/knowledge-base/from-unanswered/${item.id}`}
                  className="shrink-0 rounded-lg bg-slate-800 px-3 py-2 text-xs text-white"
                >
                  Criar resposta
                </Link>
              )}
            </div>

            <form action={updateUnansweredStatusAction} className="mt-3 flex flex-wrap items-center gap-2">
              <input type="hidden" name="id" value={item.id} />
              <select name="status" defaultValue={item.status} className="rounded-lg border border-slate-300 px-2 py-1 text-xs">
                {STATUS_OPTIONS.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              <input
                name="adminNote"
                defaultValue={item.adminNote ?? ""}
                placeholder="Observação administrativa"
                className="flex-1 min-w-[160px] rounded-lg border border-slate-300 px-2 py-1 text-xs"
              />
              <button className="rounded-lg border border-slate-300 px-3 py-1 text-xs">Salvar</button>
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}
