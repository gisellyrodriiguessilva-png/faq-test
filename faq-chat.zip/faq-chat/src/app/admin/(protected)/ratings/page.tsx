import { countRatings } from "@/lib/db/repositories/ratings";
import { getDb } from "@/lib/db/client";

export default function RatingsPage() {
  const totals = countRatings();
  const db = getDb();
  const ratingsWithFaq = db
    .prepare(
      `SELECT r.*, f.main_question FROM ratings r
       JOIN faq_contents f ON f.id = r.faq_id
       ORDER BY r.created_at DESC LIMIT 100`
    )
    .all() as any[];

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-lg font-semibold text-slate-800">Avaliações</h1>
        <p className="text-sm text-slate-500">
          {totals.positive} positivas • {totals.negative} negativas
        </p>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 text-slate-500">
            <tr>
              <th className="p-3">Pergunta</th>
              <th className="p-3">Avaliação</th>
              <th className="p-3">Comentário</th>
              <th className="p-3">Data</th>
            </tr>
          </thead>
          <tbody>
            {ratingsWithFaq.length === 0 && (
              <tr>
                <td colSpan={4} className="p-4 text-center text-slate-400">
                  Nenhuma avaliação registrada ainda.
                </td>
              </tr>
            )}
            {ratingsWithFaq.map((r) => (
              <tr key={r.id} className="border-b border-slate-100 last:border-0">
                <td className="p-3">{r.main_question}</td>
                <td className="p-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs ${
                      r.is_positive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                    }`}
                  >
                    {r.is_positive ? "Positiva" : "Negativa"}
                  </span>
                </td>
                <td className="p-3 text-slate-500">{r.comment || "—"}</td>
                <td className="p-3 text-slate-400">{new Date(r.created_at).toLocaleString("pt-BR")}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
