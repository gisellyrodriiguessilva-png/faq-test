import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentAdmin } from "@/lib/auth/session";
import { logoutAction } from "@/actions/auth";

const NAV = [
  { href: "/admin/dashboard", label: "Visão geral" },
  { href: "/admin/knowledge-base", label: "Base de conhecimento" },
  { href: "/admin/unanswered", label: "Perguntas não respondidas" },
  { href: "/admin/ratings", label: "Avaliações" },
];

export default async function ProtectedAdminLayout({ children }: { children: React.ReactNode }) {
  const admin = await getCurrentAdmin();
  if (!admin) {
    redirect("/admin/login");
  }

  return (
    <div className="flex min-h-screen flex-1">
      <aside className="w-64 shrink-0 border-r border-slate-200 bg-white p-4">
        <h2 className="text-sm font-semibold text-slate-800">FAQ Chat — Admin</h2>
        <p className="mt-1 text-xs text-slate-400">Olá, {admin.name}</p>
        <nav className="mt-6 flex flex-col gap-1">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-lg px-3 py-2 text-sm text-slate-600 hover:bg-slate-100"
            >
              {item.label}
            </Link>
          ))}
        </nav>
        <form action={logoutAction} className="mt-6">
          <button className="text-sm text-slate-400 underline" type="submit">
            Sair
          </button>
        </form>
      </aside>
      <div className="flex-1 p-6">{children}</div>
    </div>
  );
}
