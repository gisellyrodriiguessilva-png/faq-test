import { notFound } from "next/navigation";
import { getFaqById, getChangeLog } from "@/lib/db/repositories/faqContents";
import { listCategories } from "@/lib/db/repositories/categories";
import { updateFaqAction, setFaqStatusAction, duplicateFaqAction, deleteFaqAction } from "@/actions/faqContents";
import FaqForm from "@/components/admin/FaqForm";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";

export default async function EditFaqPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const faq = getFaqById(id);
  if (!faq) notFound();

  const categories = listCategories();
  const history = getChangeLog(id);

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-slate-800">Editar conteúdo</h1>
          <p className="text-sm text-slate-500">
            Status atual:{" "}
            <span
              className={`rounded-full px-2 py-0.5 text-xs ${
                faq.status === "PUBLICADO"
                  ? "bg-green-100 text-green-700"
                  : faq.status === "RASCUNHO"
                  ? "bg-amber-100 text-amber-700"
                  : "bg-slate-100 text-slate-500"
              }`}
            >
              {faq.status}
            </span>
          </p>
        </div>
        <div className="flex gap-2 text-sm">
          {faq.status !== "PUBLICADO" && (
            <form action={setFaqStatusAction.bind(null, faq.id, "PUBLICADO")}>
              <button className="rounded-lg bg-slate-800 px-3 py-2 text-white">Publicar</button>
            </form>
          )}
          {faq.status !== "INATIVO" && (
            <form action={setFaqStatusAction.bind(null, faq.id, "INATIVO")}>
              <button className="rounded-lg border border-slate-300 px-3 py-2">Desativar</button>
            </form>
          )}
          <form action={duplicateFaqAction.bind(null, faq.id)}>
            <button className="rounded-lg border border-slate-300 px-3 py-2">Duplicar</button>
          </form>
          <form action={deleteFaqAction.bind(null, faq.id)}>
            <ConfirmSubmitButton
              className="rounded-lg border border-red-300 px-3 py-2 text-red-600"
              confirmMessage="Tem certeza que deseja excluir este conteúdo? Essa ação não pode ser desfeita."
            >
              Excluir
            </ConfirmSubmitButton>
          </form>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 bg-white p-3 text-xs text-slate-500">
        <p className="font-semibold text-slate-600">Pré-visualização de como aparece no chat:</p>
        <div className="mt-2 whitespace-pre-wrap rounded-lg bg-slate-50 p-3 text-sm text-slate-800">
          {faq.approvedAnswer}
        </div>
      </div>

      <FaqForm
        categories={categories}
        initialValues={{
          mainQuestion: faq.mainQuestion,
          approvedAnswer: faq.approvedAnswer,
          categoryId: faq.categoryId,
          responsibleSector: faq.responsibleSector ?? "",
          internalNotes: faq.internalNotes ?? "",
          alternativeQuestions: faq.alternativeQuestions,
          keywords: faq.keywords,
          relatedLinks: faq.relatedLinks.map((l) => ({ title: l.title, url: l.url, openInNewTab: l.openInNewTab })),
        }}
        action={updateFaqAction.bind(null, faq.id)}
        submitLabel="Salvar alterações"
      />

      <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <h2 className="text-sm font-semibold text-slate-700">Histórico de alterações</h2>
        <ul className="mt-2 space-y-1 text-xs text-slate-500">
          {history.length === 0 && <li>Nenhuma alteração registrada ainda.</li>}
          {history.map((h: any) => (
            <li key={h.id}>
              {new Date(h.created_at).toLocaleString("pt-BR")} — {h.action_type}
              {h.changed_field ? ` (${h.changed_field})` : ""}
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
