import Link from "next/link";
import { listFaqs } from "@/lib/db/repositories/faqContents";
import { listCategories } from "@/lib/db/repositories/categories";
import { setFaqStatusAction, deleteFaqAction, duplicateFaqAction } from "@/actions/faqContents";
import ConfirmSubmitButton from "@/components/admin/ConfirmSubmitButton";

export default async function KnowledgeBasePage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string; categoryId?: string; q?: string }>;
}) {
  const params = await searchParams;
  const categories = listCategories();
  const faqs = listFaqs({
    status: params.status as any,
    categoryId: params.categoryId,
    search: params.q,
  });

  const categoryName = (id: string) => categories.find((c) => c.id === id)?.name ?? "—";

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold text-slate-800">Base de conhecimento</h1>
          <p className="text-sm text-slate-500">Cadastre, edite e publique as respostas usadas no chat.</p>
        </div>
        <div className="flex gap-2">
          <Link href="/admin/categories" className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            Categorias
          </Link>
          <Link href="/admin/knowledge-base/new" className="rounded-lg bg-slate-800 px-3 py-2 text-sm text-white">
            Novo conteúdo
          </Link>
        </div>
      </div>

      <form className="flex flex-wrap gap-2" method="get">
        <input
          name="q"
          defaultValue={params.q}
          placeholder="Pesquisar por pergunta ou resposta..."
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
        />
        <select name="status" defaultValue={params.status ?? ""} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
          <option value="">Todos os status</option>
          <option value="RASCUNHO">Rascunho</option>
          <option value="PUBLICADO">Publicado</option>
          <option value="INATIVO">Inativo</option>
        </select>
        <select
          name="categoryId"
          defaultValue={params.categoryId ?? ""}
          className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
        >
          <option value="">Todas as categorias</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
        <button className="rounded-lg border border-slate-300 px-3 py-2 text-sm">Filtrar</button>
      </form>

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 text-slate-500">
            <tr>
              <th className="p-3">Pergunta</th>
              <th className="p-3">Categoria</th>
              <th className="p-3">Status</th>
              <th className="p-3">Exibições</th>
              <th className="p-3">Ações</th>
            </tr>
          </thead>
          <tbody>
            {faqs.length === 0 && (
              <tr>
                <td colSpan={5} className="p-4 text-center text-slate-400">
                  Nenhum conteúdo encontrado.
                </td>
              </tr>
            )}
            {faqs.map((f) => (
              <tr key={f.id} className="border-b border-slate-100 last:border-0 align-top">
                <td className="p-3">
                  <Link href={`/admin/knowledge-base/${f.id}`} className="font-medium text-slate-800 hover:underline">
                    {f.mainQuestion}
                  </Link>
                </td>
                <td className="p-3 text-slate-500">{categoryName(f.categoryId)}</td>
                <td className="p-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs ${
                      f.status === "PUBLICADO"
                        ? "bg-green-100 text-green-700"
                        : f.status === "RASCUNHO"
                        ? "bg-amber-100 text-amber-700"
                        : "bg-slate-100 text-slate-500"
                    }`}
                  >
                    {f.status}
                  </span>
                </td>
                <td className="p-3 text-slate-500">{f.viewCount}</td>
                <td className="p-3">
                  <div className="flex flex-wrap gap-2 text-xs">
                    {f.status !== "PUBLICADO" && (
                      <form action={setFaqStatusAction.bind(null, f.id, "PUBLICADO")}>
                        <button className="text-blue-600 underline">Publicar</button>
                      </form>
                    )}
                    {f.status !== "INATIVO" && (
                      <form action={setFaqStatusAction.bind(null, f.id, "INATIVO")}>
                        <button className="text-slate-500 underline">Desativar</button>
                      </form>
                    )}
                    {f.status === "INATIVO" && (
                      <form action={setFaqStatusAction.bind(null, f.id, "RASCUNHO")}>
                        <button className="text-slate-500 underline">Reativar (rascunho)</button>
                      </form>
                    )}
                    <form action={duplicateFaqAction.bind(null, f.id)}>
                      <button className="text-slate-500 underline">Duplicar</button>
                    </form>
                    <form action={deleteFaqAction.bind(null, f.id)}>
                      <ConfirmSubmitButton
                        className="text-red-600 underline"
                        confirmMessage="Tem certeza que deseja excluir este conteúdo? Essa ação não pode ser desfeita."
                      >
                        Excluir
                      </ConfirmSubmitButton>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
