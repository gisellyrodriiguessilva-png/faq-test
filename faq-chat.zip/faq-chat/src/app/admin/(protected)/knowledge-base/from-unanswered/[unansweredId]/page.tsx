import { notFound } from "next/navigation";
import { getUnansweredById } from "@/lib/db/repositories/unanswered";
import { listCategories } from "@/lib/db/repositories/categories";
import { createFaqAction } from "@/actions/faqContents";
import FaqForm from "@/components/admin/FaqForm";

export default async function CreateFaqFromUnansweredPage({
  params,
}: {
  params: Promise<{ unansweredId: string }>;
}) {
  const { unansweredId } = await params;
  const unanswered = getUnansweredById(unansweredId);
  if (!unanswered) notFound();

  const categories = listCategories({ onlyActive: true });

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h1 className="text-lg font-semibold text-slate-800">Criar resposta a partir de dúvida não respondida</h1>
        <p className="text-sm text-slate-500">
          A pergunta original foi usada como ponto de partida. Ajuste como preferir antes de salvar.
        </p>
      </div>
      <FaqForm
        categories={categories}
        initialValues={{
          mainQuestion: unanswered.originalQuestion,
          approvedAnswer: "",
          categoryId: "",
          responsibleSector: "",
          internalNotes: "",
          alternativeQuestions: [],
          keywords: [],
          relatedLinks: [],
        }}
        action={createFaqAction.bind(null, unansweredId)}
        submitLabel="Salvar como rascunho e vincular"
      />
    </div>
  );
}
