import { listCategories } from "@/lib/db/repositories/categories";
import { createFaqAction } from "@/actions/faqContents";
import FaqForm from "@/components/admin/FaqForm";

export default function NewFaqPage() {
  const categories = listCategories({ onlyActive: true });

  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-lg font-semibold text-slate-800">Novo conteúdo</h1>
      <FaqForm
        categories={categories}
        action={createFaqAction.bind(null, undefined)}
        submitLabel="Salvar como rascunho"
      />
    </div>
  );
}
