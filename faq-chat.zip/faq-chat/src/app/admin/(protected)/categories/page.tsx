import { listCategories } from "@/lib/db/repositories/categories";
import { createCategoryAction, setCategoryStatusAction } from "@/actions/categories";

export default function CategoriesPage() {
  const categories = listCategories();

  return (
    <div className="flex flex-col gap-6 max-w-2xl">
      <div>
        <h1 className="text-lg font-semibold text-slate-800">Categorias</h1>
        <p className="text-sm text-slate-500">Organize os conteúdos da base de conhecimento por assunto.</p>
      </div>

      <form action={createCategoryAction} className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <h2 className="text-sm font-semibold text-slate-700">Nova categoria</h2>
        <div className="mt-3 flex flex-col gap-2">
          <input
            name="name"
            placeholder="Nome (ex.: Pagamentos)"
            required
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <input
            name="description"
            placeholder="Descrição (opcional)"
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <button type="submit" className="self-start rounded-lg bg-slate-800 px-4 py-2 text-sm text-white">
            Criar categoria
          </button>
        </div>
      </form>

      <div className="rounded-xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-slate-200 text-slate-500">
            <tr>
              <th className="p-3">Nome</th>
              <th className="p-3">Status</th>
              <th className="p-3">Ação</th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id} className="border-b border-slate-100 last:border-0">
                <td className="p-3">{c.name}</td>
                <td className="p-3">
                  <span
                    className={`rounded-full px-2 py-0.5 text-xs ${
                      c.status === "ATIVA" ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-500"
                    }`}
                  >
                    {c.status}
                  </span>
                </td>
                <td className="p-3">
                  <form
                    action={setCategoryStatusAction.bind(null, c.id, c.status === "ATIVA" ? "INATIVA" : "ATIVA")}
                  >
                    <button className="text-xs text-blue-600 underline">
                      {c.status === "ATIVA" ? "Desativar" : "Ativar"}
                    </button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
