import { listFaqs } from "@/lib/db/repositories/faqContents";
import { listUnanswered } from "@/lib/db/repositories/unanswered";
import { countQueriesByResultType, mostConsultedFaqs } from "@/lib/db/repositories/queries";
import { countRatings, listRecentNegativeRatings } from "@/lib/db/repositories/ratings";

function Card({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
      <p className="text-xs text-slate-500">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-slate-800">{value}</p>
    </div>
  );
}

export default function DashboardPage() {
  const allFaqs = listFaqs();
  const published = allFaqs.filter((f) => f.status === "PUBLICADO").length;
  const drafts = allFaqs.filter((f) => f.status === "RASCUNHO").length;
  const inactive = allFaqs.filter((f) => f.status === "INATIVO").length;

  const unanswered = listUnanswered();
  const pendingUnanswered = unanswered.filter((u) =>
    ["PENDENTE", "EM_ANALISE"].includes(u.status)
  );

  const byResult = countQueriesByResultType();
  const totalQueries = byResult.ALTA + byResult.MEDIA + byResult.BAIXA;
  const answeredPct = totalQueries > 0 ? Math.round(((byResult.ALTA + byResult.MEDIA) / totalQueries) * 100) : 0;

  const ratings = countRatings();
  const mostConsulted = mostConsultedFaqs(5);
  const recentNegative = listRecentNegativeRatings(5);

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-lg font-semibold text-slate-800">Visão geral</h1>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        <Card label="Conteúdos cadastrados" value={allFaqs.length} />
        <Card label="Publicados" value={published} />
        <Card label="Rascunhos" value={drafts} />
        <Card label="Inativos" value={inactive} />
        <Card label="Perguntas realizadas" value={totalQueries} />
        <Card label="Respondidas (alta/média)" value={byResult.ALTA + byResult.MEDIA} />
        <Card label="Não respondidas" value={byResult.BAIXA} />
        <Card label="% de perguntas respondidas" value={`${answeredPct}%`} />
        <Card label="Avaliações positivas" value={ratings.positive} />
        <Card label="Avaliações negativas" value={ratings.negative} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <h2 className="text-sm font-semibold text-slate-700">Perguntas mais consultadas</h2>
          <ul className="mt-2 space-y-2 text-sm text-slate-600">
            {mostConsulted.length === 0 && <li className="text-slate-400">Sem dados ainda.</li>}
            {mostConsulted.map((f: any) => (
              <li key={f.id} className="flex justify-between gap-2">
                <span className="truncate">{f.main_question}</span>
                <span className="shrink-0 text-slate-400">{f.total}x</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <h2 className="text-sm font-semibold text-slate-700">Não respondidas mais recorrentes</h2>
          <ul className="mt-2 space-y-2 text-sm text-slate-600">
            {pendingUnanswered.length === 0 && <li className="text-slate-400">Nenhuma pendência.</li>}
            {pendingUnanswered.slice(0, 5).map((u) => (
              <li key={u.id} className="flex justify-between gap-2">
                <span className="truncate">{u.originalQuestion}</span>
                <span className="shrink-0 text-slate-400">{u.occurrenceCount}x</span>
              </li>
            ))}
          </ul>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <h2 className="text-sm font-semibold text-slate-700">Avaliações negativas recentes</h2>
          <ul className="mt-2 space-y-2 text-sm text-slate-600">
            {recentNegative.length === 0 && <li className="text-slate-400">Nenhuma avaliação negativa.</li>}
            {recentNegative.map((r: any) => (
              <li key={r.id} className="truncate">{r.main_question}</li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  );
}
