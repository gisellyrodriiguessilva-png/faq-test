import { listCategories } from "@/lib/db/repositories/categories";
import { listPublishedFaqs } from "@/lib/db/repositories/faqContents";
import ChatWidget from "@/components/chat/ChatWidget";

export const dynamic = "force-dynamic";

export default function ChatPage() {
  const categories = listCategories({ onlyActive: true });
  const suggested = listPublishedFaqs()
    .sort((a, b) => b.viewCount - a.viewCount)
    .slice(0, 6)
    .map((f) => ({ id: f.id, mainQuestion: f.mainQuestion }));

  return (
    <main className="flex-1 flex flex-col items-center px-4 py-8">
      <div className="w-full max-w-2xl">
        <ChatWidget
          categories={categories.map((c) => ({ id: c.id, name: c.name }))}
          suggestedQuestions={suggested}
        />
      </div>
    </main>
  );
}
