"use client";

import { useState, useRef, useEffect } from "react";
import {
  askQuestionAction,
  selectSuggestionAction,
  noneOfSuggestionsMatchAction,
  type ChatAnswerResponse,
} from "@/actions/chat";
import { submitRatingAction } from "@/actions/ratings";

type Category = { id: string; name: string };
type SuggestedQuestion = { id: string; mainQuestion: string };

type ChatMessage =
  | { role: "user"; id: string; text: string }
  | {
      role: "assistant";
      id: string;
      queryId: string;
      confidence: "ALTA" | "MEDIA" | "BAIXA";
      normalizedQuestion: string;
      originalQuestion: string;
      bestScore: number;
      answer: ChatAnswerResponse["answer"];
      suggestions: ChatAnswerResponse["suggestions"];
      fallbackMessage: string | null;
      rated?: "up" | "down";
      showCommentBox?: boolean;
    };

function uid() {
  return Math.random().toString(36).slice(2);
}

export default function ChatWidget({
  categories,
  suggestedQuestions,
}: {
  categories: Category[];
  suggestedQuestions: SuggestedQuestion[];
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  async function sendQuestion(question: string) {
    const trimmed = question.trim();
    if (!trimmed || loading) return;

    setMessages((prev) => [...prev, { role: "user", id: uid(), text: trimmed }]);
    setInput("");
    setLoading(true);

    try {
      const result = await askQuestionAction(trimmed);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          id: uid(),
          queryId: result.queryId,
          confidence: result.confidence,
          normalizedQuestion: result.normalizedQuestion,
          originalQuestion: trimmed,
          bestScore: result.bestScore,
          answer: result.answer,
          suggestions: result.suggestions,
          fallbackMessage: result.fallbackMessage,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  async function pickSuggestion(messageId: string, faqId: string) {
    const answer = await selectSuggestionAction(faqId);
    setMessages((prev) =>
      prev.map((m) => (m.role === "assistant" && m.id === messageId ? { ...m, answer, suggestions: [] } : m))
    );
  }

  async function noneMatch(message: Extract<ChatMessage, { role: "assistant" }>) {
    await noneOfSuggestionsMatchAction(message.originalQuestion, message.normalizedQuestion, message.bestScore);
    setMessages((prev) =>
      prev.map((m) =>
        m.id === message.id
          ? {
              ...m,
              suggestions: [],
              fallbackMessage:
                "Certo, registrei sua dúvida para a equipe administrativa revisar. Tente reformular a pergunta ou fale diretamente com a equipe.",
            }
          : m
      )
    );
  }

  async function rate(message: Extract<ChatMessage, { role: "assistant" }>, isPositive: boolean) {
    if (!message.answer) return;
    if (!isPositive) {
      setMessages((prev) => (prev.map((m) => (m.id === message.id ? { ...m, showCommentBox: true } : m))));
      return;
    }
    await submitRatingAction({ queryId: message.queryId, faqId: message.answer.faqId, isPositive: true });
    setMessages((prev) => (prev.map((m) => (m.id === message.id ? { ...m, rated: "up" } : m))));
  }

  async function submitNegative(message: Extract<ChatMessage, { role: "assistant" }>, comment: string) {
    if (!message.answer) return;
    await submitRatingAction({
      queryId: message.queryId,
      faqId: message.answer.faqId,
      isPositive: false,
      comment,
    });
    setMessages((prev) =>
      prev.map((m) => (m.id === message.id ? { ...m, rated: "down", showCommentBox: false } : m))
    );
  }

  function clearConversation() {
    setMessages([]);
  }

  return (
    <div className="flex flex-col gap-4">
      <header className="text-center">
        <h1 className="text-2xl font-semibold text-slate-800">Assistente de Dúvidas Administrativas</h1>
        <p className="mt-1 text-sm text-slate-500">
          Olá! Sou o assistente de dúvidas da equipe administrativa. Digite sua pergunta ou escolha um dos assuntos
          abaixo.
        </p>
      </header>

      {categories.length > 0 && (
        <div className="flex flex-wrap justify-center gap-2">
          {categories.map((c) => (
            <span key={c.id} className="rounded-full bg-slate-200 px-3 py-1 text-xs text-slate-600">
              {c.name}
            </span>
          ))}
        </div>
      )}

      {suggestedQuestions.length > 0 && messages.length === 0 && (
        <div className="grid gap-2 sm:grid-cols-2">
          {suggestedQuestions.map((q) => (
            <button
              key={q.id}
              onClick={() => sendQuestion(q.mainQuestion)}
              className="rounded-lg border border-slate-200 bg-white px-3 py-2 text-left text-sm text-slate-700 shadow-sm hover:border-slate-300 hover:bg-slate-50"
            >
              {q.mainQuestion}
            </button>
          ))}
        </div>
      )}

      <div className="flex-1 rounded-xl border border-slate-200 bg-white p-4 shadow-sm min-h-[320px] flex flex-col gap-3">
        {messages.length === 0 && (
          <p className="m-auto text-sm text-slate-400">Sua conversa aparecerá aqui.</p>
        )}

        {messages.map((m) =>
          m.role === "user" ? (
            <div key={m.id} className="flex justify-end">
              <div className="max-w-[80%] rounded-2xl rounded-br-sm bg-slate-800 px-4 py-2 text-sm text-white">
                {m.text}
              </div>
            </div>
          ) : (
            <div key={m.id} className="flex justify-start">
              <div className="max-w-[85%] rounded-2xl rounded-bl-sm bg-slate-100 px-4 py-3 text-sm text-slate-800">
                {m.answer && (
                  <>
                    <div className="whitespace-pre-wrap">{m.answer.approvedAnswerHtml}</div>
                    {m.answer.relatedLinks.length > 0 && (
                      <ul className="mt-2 space-y-1 text-xs">
                        {m.answer.relatedLinks.map((l, i) => (
                          <li key={i}>
                            <a
                              href={l.url}
                              target={l.openInNewTab ? "_blank" : undefined}
                              rel="noreferrer"
                              className="text-blue-600 underline"
                            >
                              {l.title}
                            </a>
                          </li>
                        ))}
                      </ul>
                    )}

                    {!m.rated && !m.showCommentBox && (
                      <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
                        <span>Esta resposta ajudou?</span>
                        <button
                          onClick={() => rate(m, true)}
                          className="rounded-full border border-slate-300 px-2 py-0.5 hover:bg-white"
                        >
                          Sim
                        </button>
                        <button
                          onClick={() => rate(m, false)}
                          className="rounded-full border border-slate-300 px-2 py-0.5 hover:bg-white"
                        >
                          Não
                        </button>
                      </div>
                    )}
                    {m.showCommentBox && (
                      <NegativeCommentBox onSubmit={(comment) => submitNegative(m, comment)} />
                    )}
                    {m.rated && (
                      <p className="mt-2 text-xs text-slate-400">Obrigado pelo retorno!</p>
                    )}
                  </>
                )}

                {!m.answer && m.suggestions.length > 0 && (
                  <div>
                    <p>Encontrei alguns assuntos relacionados. Qual deles corresponde à sua dúvida?</p>
                    <div className="mt-2 flex flex-col gap-2">
                      {m.suggestions.map((s) => (
                        <button
                          key={s.faqId}
                          onClick={() => pickSuggestion(m.id, s.faqId)}
                          className="rounded-lg border border-slate-300 bg-white px-3 py-2 text-left text-sm hover:bg-slate-50"
                        >
                          {s.mainQuestion}
                        </button>
                      ))}
                      <button
                        onClick={() => noneMatch(m)}
                        className="text-left text-xs text-slate-500 underline"
                      >
                        Nenhuma dessas corresponde à minha dúvida
                      </button>
                    </div>
                  </div>
                )}

                {!m.answer && m.suggestions.length === 0 && m.fallbackMessage && (
                  <p>{m.fallbackMessage}</p>
                )}
              </div>
            </div>
          )
        )}

        {loading && (
          <div className="flex justify-start">
            <div className="rounded-2xl rounded-bl-sm bg-slate-100 px-4 py-2 text-sm text-slate-400">
              Procurando na base de conhecimento...
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          sendQuestion(input);
        }}
        className="flex gap-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Digite sua dúvida sobre os processos administrativos..."
          className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-slate-500 focus:outline-none"
        />
        <button
          type="submit"
          disabled={loading}
          className="rounded-lg bg-slate-800 px-4 py-2 text-sm font-medium text-white disabled:opacity-50"
        >
          Enviar
        </button>
      </form>

      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>As respostas apresentadas são baseadas nos conteúdos cadastrados e aprovados pela equipe administrativa.</span>
        {messages.length > 0 && (
          <button onClick={clearConversation} className="shrink-0 underline">
            Limpar conversa
          </button>
        )}
      </div>
    </div>
  );
}

function NegativeCommentBox({ onSubmit }: { onSubmit: (comment: string) => void }) {
  const [comment, setComment] = useState("");
  return (
    <div className="mt-2 flex flex-col gap-2">
      <textarea
        value={comment}
        onChange={(e) => setComment(e.target.value)}
        placeholder="Quer contar o que faltou? (opcional)"
        className="rounded-lg border border-slate-300 px-2 py-1 text-xs"
        rows={2}
      />
      <button
        onClick={() => onSubmit(comment)}
        className="self-start rounded-full bg-slate-800 px-3 py-1 text-xs text-white"
      >
        Enviar avaliação
      </button>
    </div>
  );
}
