"use client";

export default function ConfirmSubmitButton({
  className,
  confirmMessage,
  children,
}: {
  className?: string;
  confirmMessage: string;
  children: React.ReactNode;
}) {
  return (
    <button
      className={className}
      onClick={(e) => {
        if (!window.confirm(confirmMessage)) {
          e.preventDefault();
        }
      }}
    >
      {children}
    </button>
  );
}
