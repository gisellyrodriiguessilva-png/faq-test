"use client";

import { useState } from "react";
import { checkDuplicatesAction } from "@/actions/faqContents";

type Category = { id: string; name: string };
type LinkItem = { title: string; url: string; openInNewTab: boolean };

export type FaqFormInitialValues = {
  mainQuestion: string;
  approvedAnswer: string;
  categoryId: string;
  responsibleSector: string;
  internalNotes: string;
  alternativeQuestions: string[];
  keywords: string[];
  relatedLinks: LinkItem[];
};

const EMPTY: FaqFormInitialValues = {
  mainQuestion: "",
  approvedAnswer: "",
  categoryId: "",
  responsibleSector: "",
  internalNotes: "",
  alternativeQuestions: [],
  keywords: [],
  relatedLinks: [],
};

function TagListEditor({
  label,
  placeholder,
  items,
  setItems,
}: {
  label: string;
  placeholder: string;
  items: string[];
  setItems: (items: string[]) => void;
}) {
  const [draft, setDraft] = useState("");

  function add() {
    const v = draft.trim();
    if (!v) return;
    setItems([...items, v]);
    setDraft("");
  }

  return (
    <div>
      <label className="text-sm font-medium text-slate-700">{label}</label>
      <div className="mt-1 flex gap-2">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add();
            }
          }}
          placeholder={placeholder}
          className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
        />
        <button type="button" onClick={add} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
          Adicionar
        </button>
      </div>
      <div className="mt-2 flex flex-wrap gap-2">
        {items.map((item, i) => (
          <span key={i} className="flex items-center gap-1 rounded-full bg-slate-100 px-3 py-1 text-xs text-slate-700">
            {item}
            <button
              type="button"
              onClick={() => setItems(items.filter((_, idx) => idx !== i))}
              className="text-slate-400 hover:text-slate-700"
            >
              ×
            </button>
          </span>
        ))}
      </div>
    </div>
  );
}

export default function FaqForm({
  categories,
  initialValues = EMPTY,
  action,
  submitLabel,
}: {
  categories: Category[];
  initialValues?: FaqFormInitialValues;
  action: (formData: FormData) => void;
  submitLabel: string;
}) {
  const [mainQuestion, setMainQuestion] = useState(initialValues.mainQuestion);
  const [approvedAnswer, setApprovedAnswer] = useState(initialValues.approvedAnswer);
  const [categoryId, setCategoryId] = useState(initialValues.categoryId);
  const [responsibleSector, setResponsibleSector] = useState(initialValues.responsibleSector);
  const [internalNotes, setInternalNotes] = useState(initialValues.internalNotes);
  const [alternativeQuestions, setAlternativeQuestions] = useState(initialValues.alternativeQuestions);
  const [keywords, setKeywords] = useState(initialValues.keywords);
  const [links, setLinks] = useState<LinkItem[]>(initialValues.relatedLinks);
  const [linkDraft, setLinkDraft] = useState({ title: "", url: "", openInNewTab: true });
  const [duplicateWarning, setDuplicateWarning] = useState<string[] | null>(null);
  const [checking, setChecking] = useState(false);

  async function handleBlurCheckDuplicates() {
    if (!mainQuestion.trim()) return;
    setChecking(true);
    try {
      const dups = await checkDuplicatesAction(mainQuestion);
      setDuplicateWarning(dups.length > 0 ? dups.map((d) => d.mainQuestion) : null);
    } finally {
      setChecking(false);
    }
  }

  function addLink() {
    if (!linkDraft.title.trim() || !linkDraft.url.trim()) return;
    setLinks([...links, linkDraft]);
    setLinkDraft({ title: "", url: "", openInNewTab: true });
  }

  return (
    <form action={action} className="flex flex-col gap-5 max-w-3xl">
      <div>
        <label className="text-sm font-medium text-slate-700">Pergunta principal</label>
        <input
          name="mainQuestion"
          value={mainQuestion}
          onChange={(e) => setMainQuestion(e.target.value)}
          onBlur={handleBlurCheckDuplicates}
          required
          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          placeholder="Como solicitar o pagamento de um fornecedor?"
        />
        {checking && <p className="mt-1 text-xs text-slate-400">Verificando duplicidade...</p>}
        {duplicateWarning && (
          <p className="mt-1 rounded-md bg-amber-50 p-2 text-xs text-amber-700">
            Já existe um conteúdo semelhante na base ({duplicateWarning.join(", ")}). Revise os registros antes de
            continuar.
          </p>
        )}
      </div>

      <div>
        <label className="text-sm font-medium text-slate-700">Resposta aprovada</label>
        <textarea
          name="approvedAnswer"
          value={approvedAnswer}
          onChange={(e) => setApprovedAnswer(e.target.value)}
          required
          rows={8}
          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          placeholder="Texto exato que será exibido no chat. Parágrafos e quebras de linha são preservados."
        />
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="text-sm font-medium text-slate-700">Categoria</label>
          <select
            name="categoryId"
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            required
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          >
            <option value="" disabled>
              Selecione...
            </option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-sm font-medium text-slate-700">Setor responsável (opcional)</label>
          <input
            name="responsibleSector"
            value={responsibleSector}
            onChange={(e) => setResponsibleSector(e.target.value)}
            className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
        </div>
      </div>

      <TagListEditor
        label="Perguntas alternativas"
        placeholder="Ex.: Como pagar um fornecedor?"
        items={alternativeQuestions}
        setItems={setAlternativeQuestions}
      />
      <TagListEditor
        label="Palavras-chave"
        placeholder="Ex.: nota fiscal"
        items={keywords}
        setItems={setKeywords}
      />

      <div>
        <label className="text-sm font-medium text-slate-700">Links relacionados</label>
        <div className="mt-1 flex flex-col gap-2 sm:flex-row">
          <input
            value={linkDraft.title}
            onChange={(e) => setLinkDraft({ ...linkDraft, title: e.target.value })}
            placeholder="Título"
            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <input
            value={linkDraft.url}
            onChange={(e) => setLinkDraft({ ...linkDraft, url: e.target.value })}
            placeholder="https://..."
            className="flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
          />
          <button type="button" onClick={addLink} className="rounded-lg border border-slate-300 px-3 py-2 text-sm">
            Adicionar link
          </button>
        </div>
        <ul className="mt-2 space-y-1 text-sm">
          {links.map((l, i) => (
            <li key={i} className="flex items-center justify-between rounded-lg bg-slate-50 px-3 py-1">
              <span className="truncate text-slate-600">
                {l.title} — {l.url}
              </span>
              <button
                type="button"
                onClick={() => setLinks(links.filter((_, idx) => idx !== i))}
                className="text-xs text-slate-400 hover:text-slate-700"
              >
                remover
              </button>
            </li>
          ))}
        </ul>
      </div>

      <div>
        <label className="text-sm font-medium text-slate-700">Observações internas (não aparece no chat)</label>
        <textarea
          name="internalNotes"
          value={internalNotes}
          onChange={(e) => setInternalNotes(e.target.value)}
          rows={3}
          className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      <input type="hidden" name="alternativeQuestionsJson" value={JSON.stringify(alternativeQuestions)} />
      <input type="hidden" name="keywordsJson" value={JSON.stringify(keywords)} />
      <input type="hidden" name="relatedLinksJson" value={JSON.stringify(links)} />

      <button type="submit" className="self-start rounded-lg bg-slate-800 px-5 py-2 text-sm font-medium text-white">
        {submitLabel}
      </button>
    </form>
  );
}
