"use server";

import { ratingSchema } from "@/lib/validation/schemas";
import { createRating } from "@/lib/db/repositories/ratings";
import { recordUnanswered } from "@/lib/db/repositories/unanswered";
import { getQueryById } from "@/lib/db/repositories/queries";

export async function submitRatingAction(input: {
  queryId: string;
  faqId: string;
  isPositive: boolean;
  comment?: string;
  subjectWasDifferent?: boolean;
}) {
  const parsed = ratingSchema.parse(input);
  createRating(parsed);

  // Avaliação negativa marcando "o assunto era diferente" também vira pergunta não respondida.
  if (!parsed.isPositive && input.subjectWasDifferent) {
    const query = getQueryById(parsed.queryId);
    if (query) {
      recordUnanswered(query.originalQuestion, query.normalizedQuestion, query.confidenceScore);
    }
  }
}
