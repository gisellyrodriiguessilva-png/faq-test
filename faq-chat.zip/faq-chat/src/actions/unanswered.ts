"use server";

import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth/requireAdmin";
import { unansweredStatusSchema } from "@/lib/validation/schemas";
import { updateUnansweredStatus } from "@/lib/db/repositories/unanswered";

export async function updateUnansweredStatusAction(formData: FormData) {
  await requireAdmin();
  const parsed = unansweredStatusSchema.parse({
    id: formData.get("id"),
    status: formData.get("status"),
    adminNote: formData.get("adminNote") ?? "",
  });
  const admin = await requireAdmin();
  updateUnansweredStatus(parsed.id, parsed.status, admin.id, parsed.adminNote);
  revalidatePath("/admin/unanswered");
}
