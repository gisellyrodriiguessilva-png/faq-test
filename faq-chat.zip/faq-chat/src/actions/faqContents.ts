"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireAdmin } from "@/lib/auth/requireAdmin";
import { faqContentSchema } from "@/lib/validation/schemas";
import {
  createFaq,
  updateFaq,
  setFaqStatus,
  deleteFaq,
  duplicateFaq,
  findPossibleDuplicates,
  type FaqStatus,
} from "@/lib/db/repositories/faqContents";
import { linkCreatedFaq } from "@/lib/db/repositories/unanswered";

function parseFaqForm(formData: FormData) {
  return faqContentSchema.parse({
    mainQuestion: formData.get("mainQuestion"),
    approvedAnswer: formData.get("approvedAnswer"),
    categoryId: formData.get("categoryId"),
    responsibleSector: formData.get("responsibleSector") ?? "",
    internalNotes: formData.get("internalNotes") ?? "",
    alternativeQuestions: JSON.parse((formData.get("alternativeQuestionsJson") as string) || "[]"),
    keywords: JSON.parse((formData.get("keywordsJson") as string) || "[]"),
    relatedLinks: JSON.parse((formData.get("relatedLinksJson") as string) || "[]"),
  });
}

export async function checkDuplicatesAction(mainQuestion: string, excludeId?: string) {
  await requireAdmin();
  const dups = findPossibleDuplicates(mainQuestion, excludeId);
  return dups.map((d) => ({ id: d.id, mainQuestion: d.mainQuestion, status: d.status }));
}

export async function createFaqAction(sourceUnansweredId: string | undefined, formData: FormData) {
  const admin = await requireAdmin();
  const parsed = parseFaqForm(formData);
  const faq = createFaq(parsed, admin.id, sourceUnansweredId);
  if (sourceUnansweredId) {
    linkCreatedFaq(sourceUnansweredId, faq.id);
    revalidatePath("/admin/unanswered");
  }
  revalidatePath("/admin/knowledge-base");
  redirect(`/admin/knowledge-base/${faq.id}`);
}

export async function updateFaqAction(id: string, formData: FormData) {
  const admin = await requireAdmin();
  const parsed = parseFaqForm(formData);
  updateFaq(id, parsed, admin.id);
  revalidatePath("/admin/knowledge-base");
  revalidatePath(`/admin/knowledge-base/${id}`);
  redirect(`/admin/knowledge-base/${id}`);
}

export async function setFaqStatusAction(id: string, status: FaqStatus) {
  const admin = await requireAdmin();
  setFaqStatus(id, status, admin.id);
  revalidatePath("/admin/knowledge-base");
  revalidatePath(`/admin/knowledge-base/${id}`);
}

export async function deleteFaqAction(id: string) {
  const admin = await requireAdmin();
  deleteFaq(id, admin.id);
  revalidatePath("/admin/knowledge-base");
  redirect("/admin/knowledge-base");
}

export async function duplicateFaqAction(id: string) {
  const admin = await requireAdmin();
  const copy = duplicateFaq(id, admin.id);
  revalidatePath("/admin/knowledge-base");
  if (copy) redirect(`/admin/knowledge-base/${copy.id}`);
}
