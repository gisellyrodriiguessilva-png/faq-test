"use server";

import { revalidatePath } from "next/cache";
import { requireAdmin } from "@/lib/auth/requireAdmin";
import { categorySchema } from "@/lib/validation/schemas";
import { createCategory, updateCategory, setCategoryStatus } from "@/lib/db/repositories/categories";

export async function createCategoryAction(formData: FormData) {
  await requireAdmin();
  const parsed = categorySchema.parse({
    name: formData.get("name"),
    description: formData.get("description") ?? "",
  });
  createCategory(parsed);
  revalidatePath("/admin/knowledge-base");
}

export async function updateCategoryAction(id: string, formData: FormData) {
  await requireAdmin();
  const parsed = categorySchema.parse({
    name: formData.get("name"),
    description: formData.get("description") ?? "",
  });
  updateCategory(id, parsed);
  revalidatePath("/admin/knowledge-base");
}

export async function setCategoryStatusAction(id: string, status: "ATIVA" | "INATIVA") {
  await requireAdmin();
  setCategoryStatus(id, status);
  revalidatePath("/admin/knowledge-base");
}
