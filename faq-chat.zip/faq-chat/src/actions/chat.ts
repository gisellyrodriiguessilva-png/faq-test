"use server";

import { chatQuestionSchema } from "@/lib/validation/schemas";
import { searchFaqs } from "@/lib/search/engine";
import { logQuery } from "@/lib/db/repositories/queries";
import { recordUnanswered } from "@/lib/db/repositories/unanswered";
import { incrementViewCount, getFaqById } from "@/lib/db/repositories/faqContents";

export type ChatAnswerResponse = {
  queryId: string;
  confidence: "ALTA" | "MEDIA" | "BAIXA";
  normalizedQuestion: string;
  bestScore: number;
  answer: {
    faqId: string;
    mainQuestion: string;
    approvedAnswerHtml: string;
    relatedLinks: { title: string; url: string; openInNewTab: boolean }[];
  } | null;
  suggestions: { faqId: string; mainQuestion: string }[];
  fallbackMessage: string | null;
};

const FALLBACK_MESSAGE =
  "Não encontrei uma resposta segura para essa dúvida na nossa base. Tente escrever de outra forma ou encaminhe a pergunta à equipe responsável.";

export async function askQuestionAction(question: string): Promise<ChatAnswerResponse> {
  const parsed = chatQuestionSchema.parse({ question });
  const result = searchFaqs(parsed.question);

  const query = logQuery({
    originalQuestion: parsed.question,
    normalizedQuestion: result.normalizedQuestion,
    selectedFaqId: result.answer?.id ?? null,
    confidenceScore: result.bestScore,
    resultType: result.confidence,
  });

  if (result.confidence === "BAIXA") {
    recordUnanswered(parsed.question, result.normalizedQuestion, result.bestScore);
    return {
      queryId: query.id,
      confidence: "BAIXA",
      normalizedQuestion: result.normalizedQuestion,
      bestScore: result.bestScore,
      answer: null,
      suggestions: [],
      fallbackMessage: FALLBACK_MESSAGE,
    };
  }

  if (result.confidence === "MEDIA") {
    return {
      queryId: query.id,
      confidence: "MEDIA",
      normalizedQuestion: result.normalizedQuestion,
      bestScore: result.bestScore,
      answer: null,
      suggestions: result.suggestions.map((f) => ({ faqId: f.id, mainQuestion: f.mainQuestion })),
      fallbackMessage: null,
    };
  }

  incrementViewCount(result.answer!.id);
  return {
    queryId: query.id,
    confidence: "ALTA",
    normalizedQuestion: result.normalizedQuestion,
    bestScore: result.bestScore,
    answer: {
      faqId: result.answer!.id,
      mainQuestion: result.answer!.mainQuestion,
      approvedAnswerHtml: result.answer!.approvedAnswer,
      relatedLinks: result.answer!.relatedLinks,
    },
    suggestions: [],
    fallbackMessage: null,
  };
}

/** Chamado quando o usuário clica em uma das sugestões de confiança média. */
export async function selectSuggestionAction(faqId: string): Promise<ChatAnswerResponse["answer"]> {
  const faq = getFaqById(faqId);
  if (!faq || faq.status !== "PUBLICADO") return null;
  incrementViewCount(faqId);
  return {
    faqId: faq.id,
    mainQuestion: faq.mainQuestion,
    approvedAnswerHtml: faq.approvedAnswer,
    relatedLinks: faq.relatedLinks,
  };
}

/** Chamado quando o usuário diz que nenhuma sugestão corresponde à dúvida. */
export async function noneOfSuggestionsMatchAction(originalQuestion: string, normalizedQuestion: string, bestScore: number) {
  recordUnanswered(originalQuestion, normalizedQuestion, bestScore);
}
