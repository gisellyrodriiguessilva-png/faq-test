"use server";

import { redirect } from "next/navigation";
import { loginSchema } from "@/lib/validation/schemas";
import { findAdminByUsername, touchLastLogin } from "@/lib/db/repositories/adminUsers";
import { verifyPassword } from "@/lib/auth/password";
import { getSession } from "@/lib/auth/session";

export type ActionState = { error?: string } | undefined;

export async function loginAction(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const parsed = loginSchema.safeParse({
    username: formData.get("username"),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Dados inválidos." };
  }

  const admin = findAdminByUsername(parsed.data.username);
  if (!admin) {
    // Mensagem de erro genérica: nunca revelar se o usuário existe ou não.
    return { error: "Usuário ou senha inválidos." };
  }

  const valid = await verifyPassword(parsed.data.password, admin.passwordHash);
  if (!valid) {
    return { error: "Usuário ou senha inválidos." };
  }

  const session = await getSession();
  session.adminId = admin.id;
  session.adminName = admin.name;
  session.username = admin.username;
  await session.save();
  touchLastLogin(admin.id);

  redirect("/admin/dashboard");
}

export async function logoutAction() {
  const session = await getSession();
  session.destroy();
  redirect("/admin/login");
}
