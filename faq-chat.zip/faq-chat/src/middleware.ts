import { NextResponse, type NextRequest } from "next/server";

// Proteção de rotas administrativas em nível de servidor (middleware roda antes
// de qualquer renderização). A verificação completa da sessão (assinatura do
// cookie via iron-session) acontece nas próprias páginas/actions do /admin,
// pois o runtime de middleware do Next não deve depender de node:sqlite; aqui
// fazemos a primeira barreira: sem o cookie de sessão, nem chega à página.
const PUBLIC_ADMIN_PATHS = ["/admin/login"];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (!pathname.startsWith("/admin")) {
    return NextResponse.next();
  }
  if (PUBLIC_ADMIN_PATHS.some((p) => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const hasSessionCookie = request.cookies.has("faq_chat_admin_session");
  if (!hasSessionCookie) {
    const loginUrl = new URL("/admin/login", request.url);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*"],
};
