import Fuse from "fuse.js";
import { listPublishedFaqs, type FaqContent } from "@/lib/db/repositories/faqContents";
import { normalizeForMatching } from "@/lib/search/normalize";
import { classifyConfidence, SEARCH_WEIGHTS, MAX_SUGGESTIONS, type ConfidenceLevel } from "@/lib/search/config";

export type SearchMatch = {
  faq: FaqContent;
  score: number; // 0 a 1, quanto maior melhor
};

export type SearchResult = {
  normalizedQuestion: string;
  confidence: ConfidenceLevel;
  bestScore: number;
  /** Preenchido apenas quando confidence === "ALTA" */
  answer: FaqContent | null;
  /** Preenchido quando confidence === "MEDIA" (até MAX_SUGGESTIONS) */
  suggestions: FaqContent[];
};

type SearchDoc = {
  faqId: string;
  mainQuestion: string;
  alternativeQuestions: string;
  keywords: string;
};

function buildFuseIndex(faqs: FaqContent[]) {
  const docs: SearchDoc[] = faqs.map((f) => ({
    faqId: f.id,
    mainQuestion: f.mainQuestionNormalized,
    alternativeQuestions: f.alternativeQuestions.map(normalizeForMatching).join(" | "),
    keywords: f.keywords.map(normalizeForMatching).join(" | "),
  }));

  return new Fuse(docs, {
    includeScore: true,
    threshold: 0.55, // Fuse: 0 = match perfeito, 1 = não bate nada
    ignoreLocation: true,
    keys: [
      { name: "mainQuestion", weight: 0.5 },
      { name: "alternativeQuestions", weight: 0.3 },
      { name: "keywords", weight: 0.2 },
    ],
  });
}

function wordSet(text: string): Set<string> {
  return new Set(text.split(" ").filter(Boolean));
}

/** Coeficiente de Dice entre dois conjuntos de palavras: 2*|intersecção| / (|A| + |B|). */
function diceCoefficient(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 || b.size === 0) return 0;
  let intersection = 0;
  for (const word of a) if (b.has(word)) intersection++;
  return (2 * intersection) / (a.size + b.size);
}

/**
 * Similaridade por sobreposição de palavras entre a pergunta e a melhor entre
 * (pergunta principal, cada pergunta alternativa) cadastrada. Complementa o
 * Fuse.js (que mede semelhança de caracteres) captando bem paráfrases como
 * "como faço para pagar um fornecedor" vs "como pagar um fornecedor".
 */
function bestWordOverlap(queryWords: Set<string>, faq: FaqContent): number {
  const candidates = [faq.mainQuestionNormalized, ...faq.alternativeQuestions.map(normalizeForMatching)];
  let best = 0;
  for (const candidate of candidates) {
    const score = diceCoefficient(queryWords, wordSet(candidate));
    if (score > best) best = score;
  }
  return best;
}

/** Executa a busca híbrida descrita na seção 6 do documento de especificação. */
export function searchFaqs(rawQuestion: string): SearchResult {
  const normalizedQuestion = normalizeForMatching(rawQuestion);
  const questionWords = wordSet(normalizedQuestion);
  const faqs = listPublishedFaqs();

  const scored = new Map<string, number>();

  for (const faq of faqs) {
    // 1. Correspondência exata com a pergunta principal
    if (faq.mainQuestionNormalized === normalizedQuestion) {
      scored.set(faq.id, Math.max(scored.get(faq.id) ?? 0, SEARCH_WEIGHTS.exactMainQuestion));
      continue;
    }
    // 2. Correspondência exata com perguntas alternativas
    const altMatch = faq.alternativeQuestions.some((q) => normalizeForMatching(q) === normalizedQuestion);
    if (altMatch) {
      scored.set(faq.id, Math.max(scored.get(faq.id) ?? 0, SEARCH_WEIGHTS.exactAlternativeQuestion));
      continue;
    }
    // 3. Presença de palavras-chave cadastradas
    const keywordHits = faq.keywords.filter((kw) => questionWords.has(normalizeForMatching(kw))).length;
    if (keywordHits > 0) {
      const kwScore = Math.min(1, keywordHits / Math.max(faq.keywords.length, 1)) * SEARCH_WEIGHTS.keywordMatch;
      scored.set(faq.id, Math.max(scored.get(faq.id) ?? 0, kwScore));
    }
    // 4a. Similaridade aproximada por sobreposição de palavras (lida bem com paráfrases)
    const overlap = bestWordOverlap(questionWords, faq) * SEARCH_WEIGHTS.wordOverlap;
    if (overlap > 0) {
      scored.set(faq.id, Math.max(scored.get(faq.id) ?? 0, overlap));
    }
  }

  // 4b. Similaridade por caracteres (Fuse.js) — pega erros de digitação e pequenas variações
  if (faqs.length > 0) {
    const fuse = buildFuseIndex(faqs);
    const fuseResults = fuse.search(normalizedQuestion);
    for (const result of fuseResults) {
      const faqId = faqs[result.refIndex].id;
      const similarity = 1 - (result.score ?? 1); // inverte: 1 = idêntico
      const weighted = similarity * SEARCH_WEIGHTS.fuzzySimilarity;
      scored.set(faqId, Math.max(scored.get(faqId) ?? 0, weighted));
    }
  }

  const matches: SearchMatch[] = Array.from(scored.entries())
    .map(([faqId, score]) => ({ faq: faqs.find((f) => f.id === faqId)!, score }))
    .filter((m) => m.faq)
    .sort((a, b) => b.score - a.score);

  const bestScore = matches[0]?.score ?? 0;
  const confidence = classifyConfidence(bestScore);

  if (confidence === "ALTA") {
    return { normalizedQuestion, confidence, bestScore, answer: matches[0].faq, suggestions: [] };
  }
  if (confidence === "MEDIA") {
    return {
      normalizedQuestion,
      confidence,
      bestScore,
      answer: null,
      suggestions: matches.slice(0, MAX_SUGGESTIONS).map((m) => m.faq),
    };
  }
  return { normalizedQuestion, confidence, bestScore, answer: null, suggestions: [] };
}
