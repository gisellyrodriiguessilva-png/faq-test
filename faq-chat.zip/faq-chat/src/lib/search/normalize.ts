// Normalização de texto usada tanto ao cadastrar conteúdos quanto ao buscar.
// Mantida isolada para garantir que cadastro e busca normalizem exatamente da mesma forma.

const STOPWORDS = new Set([
  "a", "o", "as", "os", "de", "da", "do", "das", "dos", "e", "ou", "um", "uma",
  "para", "por", "com", "sem", "em", "no", "na", "nos", "nas", "que", "se",
  "eu", "meu", "minha", "como", "qual", "quais", "onde", "quando", "porque",
  "é", "sao", "sou", "foi", "ser", "tem", "ter", "sobre", "ao", "aos", "à",
]);

export function stripAccents(input: string): string {
  return input.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

/** Normaliza para comparação: minúsculas, sem acento, sem pontuação, espaços colapsados. */
export function normalizeText(input: string): string {
  return stripAccents(input.toLowerCase())
    .replace(/[^a-z0-9\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Versão da normalização que também remove stopwords, usada para comparação de conteúdo. */
export function normalizeForMatching(input: string): string {
  return normalizeText(input)
    .split(" ")
    .filter((word) => word.length > 0 && !STOPWORDS.has(word))
    .join(" ");
}
