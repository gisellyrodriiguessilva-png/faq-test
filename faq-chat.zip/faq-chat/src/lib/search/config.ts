// Arquivo central de configuração do motor de busca.
// Ajuste os limites aqui — nenhuma outra parte do código deve ter esses números "hardcoded".

export const CONFIDENCE_THRESHOLDS = {
  /** score >= HIGH  → exibe a resposta diretamente */
  HIGH: 0.75,
  /** MEDIUM <= score < HIGH → mostra sugestões relacionadas */
  MEDIUM: 0.45,
  // score < MEDIUM → "não encontrei resposta segura"
} as const;

export const MAX_SUGGESTIONS = 3;

/** Pesos usados para combinar as diferentes estratégias em um score final (0 a 1). */
export const SEARCH_WEIGHTS = {
  exactMainQuestion: 1.0,
  exactAlternativeQuestion: 0.97,
  keywordMatch: 0.6,
  wordOverlap: 0.9, // sobreposição de palavras entre a pergunta e conteúdos cadastrados (paráfrases)
  fuzzySimilarity: 1.0, // já normalizado pelo Fuse.js (1 - fuse.score)
  categoryBoost: 0.05, // pequeno reforço quando a categoria também bate
} as const;

export type ConfidenceLevel = "ALTA" | "MEDIA" | "BAIXA";

export function classifyConfidence(score: number): ConfidenceLevel {
  if (score >= CONFIDENCE_THRESHOLDS.HIGH) return "ALTA";
  if (score >= CONFIDENCE_THRESHOLDS.MEDIUM) return "MEDIA";
  return "BAIXA";
}
