import { z } from "zod";

export const loginSchema = z.object({
  username: z.string().min(3, "Informe o nome de usuário."),
  password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres."),
});

export const categorySchema = z.object({
  name: z.string().trim().min(2, "Informe um nome para a categoria."),
  description: z.string().trim().optional().default(""),
});

const urlField = z.string().trim().url("Informe um endereço válido (https://...).");

export const relatedLinkSchema = z.object({
  title: z.string().trim().min(1, "Informe um título para o link."),
  url: urlField,
  openInNewTab: z.boolean().default(true),
});

export const faqContentSchema = z.object({
  mainQuestion: z.string().trim().min(5, "A pergunta principal deve ter pelo menos 5 caracteres."),
  approvedAnswer: z.string().trim().min(5, "A resposta aprovada não pode ficar vazia."),
  categoryId: z.string().min(1, "Selecione uma categoria."),
  responsibleSector: z.string().trim().optional().default(""),
  internalNotes: z.string().trim().optional().default(""),
  alternativeQuestions: z.array(z.string().trim().min(1)).default([]),
  keywords: z.array(z.string().trim().min(1)).default([]),
  relatedLinks: z.array(relatedLinkSchema).default([]),
});

export const chatQuestionSchema = z.object({
  question: z.string().trim().min(2, "Digite sua dúvida.").max(500),
});

export const ratingSchema = z.object({
  queryId: z.string().min(1),
  faqId: z.string().min(1),
  isPositive: z.boolean(),
  comment: z.string().trim().max(1000).optional().default(""),
});

export const unansweredStatusSchema = z.object({
  id: z.string().min(1),
  status: z.enum(["PENDENTE", "EM_ANALISE", "TRANSFORMADA", "DUPLICADA", "DESCARTADA", "RESOLVIDA"]),
  adminNote: z.string().trim().max(1000).optional().default(""),
});

export type FaqContentInput = z.infer<typeof faqContentSchema>;
export type CategoryInput = z.infer<typeof categorySchema>;
export type LoginInput = z.infer<typeof loginSchema>;
