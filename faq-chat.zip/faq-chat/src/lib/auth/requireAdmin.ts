import { getCurrentAdmin } from "@/lib/auth/session";

/** Lança erro se não houver admin autenticado. Usar no início de toda Server Action administrativa. */
export async function requireAdmin() {
  const admin = await getCurrentAdmin();
  if (!admin) {
    throw new Error("Não autenticado.");
  }
  return admin;
}
