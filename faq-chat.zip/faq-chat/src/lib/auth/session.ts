import { cookies } from "next/headers";
import { getIronSession, type SessionOptions } from "iron-session";

export type SessionData = {
  adminId?: string;
  adminName?: string;
  username?: string;
};

const secret = process.env.SESSION_SECRET;
if (!secret || secret.length < 32) {
  // Falha alto e cedo: nunca rodar com uma sessão insegura.
  // Em desenvolvimento, veja o .env.example para gerar um valor adequado.
  throw new Error(
    "SESSION_SECRET ausente ou curto demais (mínimo 32 caracteres). Configure o .env conforme .env.example."
  );
}

export const sessionOptions: SessionOptions = {
  password: secret,
  cookieName: "faq_chat_admin_session",
  cookieOptions: {
    secure: process.env.NODE_ENV === "production",
    httpOnly: true,
    sameSite: "lax",
  },
};

export async function getSession() {
  return getIronSession<SessionData>(await cookies(), sessionOptions);
}

export async function getCurrentAdmin() {
  const session = await getSession();
  if (!session.adminId) return null;
  return { id: session.adminId, name: session.adminName, username: session.username };
}
