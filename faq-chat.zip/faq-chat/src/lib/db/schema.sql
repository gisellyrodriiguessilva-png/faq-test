-- Schema do MVP de FAQ Chat Interno
-- Compatível com SQLite (dev, via node:sqlite) e pensado para migrar para PostgreSQL depois.
-- Convenções: ids como TEXT (uuid), datas como TEXT ISO-8601, booleanos como INTEGER 0/1.

CREATE TABLE IF NOT EXISTS admin_users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ATIVO' CHECK (status IN ('ATIVO', 'INATIVO')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  last_login_at TEXT
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'ATIVA' CHECK (status IN ('ATIVA', 'INATIVA')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS unanswered_questions (
  id TEXT PRIMARY KEY,
  original_question TEXT NOT NULL,
  normalized_question TEXT NOT NULL,
  occurrence_count INTEGER NOT NULL DEFAULT 1,
  best_score_found REAL NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'PENDENTE' CHECK (
    status IN ('PENDENTE', 'EM_ANALISE', 'TRANSFORMADA', 'DUPLICADA', 'DESCARTADA', 'RESOLVIDA')
  ),
  responsible_admin_id TEXT REFERENCES admin_users(id),
  admin_note TEXT,
  created_faq_id TEXT,
  first_occurred_at TEXT NOT NULL,
  last_occurred_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_unanswered_status ON unanswered_questions(status);
CREATE INDEX IF NOT EXISTS idx_unanswered_normalized ON unanswered_questions(normalized_question);

CREATE TABLE IF NOT EXISTS faq_contents (
  id TEXT PRIMARY KEY,
  main_question TEXT NOT NULL,
  main_question_normalized TEXT NOT NULL,
  approved_answer TEXT NOT NULL,
  category_id TEXT NOT NULL REFERENCES categories(id),
  responsible_sector TEXT,
  internal_notes TEXT,
  status TEXT NOT NULL DEFAULT 'RASCUNHO' CHECK (status IN ('RASCUNHO', 'PUBLICADO', 'INATIVO')),
  created_by TEXT NOT NULL REFERENCES admin_users(id),
  updated_by TEXT NOT NULL REFERENCES admin_users(id),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  view_count INTEGER NOT NULL DEFAULT 0,
  positive_ratings INTEGER NOT NULL DEFAULT 0,
  negative_ratings INTEGER NOT NULL DEFAULT 0,
  source_unanswered_id TEXT REFERENCES unanswered_questions(id)
);
CREATE INDEX IF NOT EXISTS idx_faq_status ON faq_contents(status);
CREATE INDEX IF NOT EXISTS idx_faq_category ON faq_contents(category_id);

CREATE TABLE IF NOT EXISTS alternative_questions (
  id TEXT PRIMARY KEY,
  faq_id TEXT NOT NULL REFERENCES faq_contents(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  text_normalized TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_alt_faq ON alternative_questions(faq_id);

CREATE TABLE IF NOT EXISTS keywords (
  id TEXT PRIMARY KEY,
  faq_id TEXT NOT NULL REFERENCES faq_contents(id) ON DELETE CASCADE,
  term TEXT NOT NULL,
  term_normalized TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_kw_faq ON keywords(faq_id);

CREATE TABLE IF NOT EXISTS related_links (
  id TEXT PRIMARY KEY,
  faq_id TEXT NOT NULL REFERENCES faq_contents(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  url TEXT NOT NULL,
  open_in_new_tab INTEGER NOT NULL DEFAULT 1,
  display_order INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_link_faq ON related_links(faq_id);

CREATE TABLE IF NOT EXISTS queries (
  id TEXT PRIMARY KEY,
  original_question TEXT NOT NULL,
  normalized_question TEXT NOT NULL,
  selected_faq_id TEXT REFERENCES faq_contents(id),
  confidence_score REAL NOT NULL,
  result_type TEXT NOT NULL CHECK (result_type IN ('ALTA', 'MEDIA', 'BAIXA')),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_query_created ON queries(created_at);

CREATE TABLE IF NOT EXISTS ratings (
  id TEXT PRIMARY KEY,
  query_id TEXT NOT NULL REFERENCES queries(id),
  faq_id TEXT NOT NULL REFERENCES faq_contents(id),
  is_positive INTEGER NOT NULL CHECK (is_positive IN (0, 1)),
  comment TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rating_faq ON ratings(faq_id);

CREATE TABLE IF NOT EXISTS change_log (
  id TEXT PRIMARY KEY,
  faq_id TEXT NOT NULL REFERENCES faq_contents(id) ON DELETE CASCADE,
  admin_id TEXT NOT NULL REFERENCES admin_users(id),
  action_type TEXT NOT NULL CHECK (
    action_type IN ('CRIACAO', 'EDICAO', 'PUBLICACAO', 'DESATIVACAO', 'REATIVACAO', 'EXCLUSAO')
  ),
  changed_field TEXT,
  old_value TEXT,
  new_value TEXT,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_changelog_faq ON change_log(faq_id);
