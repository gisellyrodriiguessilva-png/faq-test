import { getDb, newId, nowIso } from "@/lib/db/client";
import { incrementRatingCount } from "@/lib/db/repositories/faqContents";

export function createRating(input: {
  queryId: string;
  faqId: string;
  isPositive: boolean;
  comment?: string;
}) {
  const db = getDb();
  const id = newId();
  db.prepare(
    `INSERT INTO ratings (id, query_id, faq_id, is_positive, comment, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(id, input.queryId, input.faqId, input.isPositive ? 1 : 0, input.comment ?? "", nowIso());
  incrementRatingCount(input.faqId, input.isPositive);
  return id;
}

export function listRecentNegativeRatings(limit = 10) {
  const db = getDb();
  return db
    .prepare(
      `SELECT r.*, f.main_question FROM ratings r
       JOIN faq_contents f ON f.id = r.faq_id
       WHERE r.is_positive = 0 ORDER BY r.created_at DESC LIMIT ?`
    )
    .all(limit) as any[];
}

export function countRatings(): { positive: number; negative: number } {
  const db = getDb();
  const row = db
    .prepare(
      "SELECT SUM(is_positive) as positive, SUM(1 - is_positive) as negative FROM ratings"
    )
    .get() as any;
  return { positive: row.positive ?? 0, negative: row.negative ?? 0 };
}

export function listRatingsForFaq(faqId: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM ratings WHERE faq_id = ? ORDER BY created_at DESC").all(faqId) as any[];
}
