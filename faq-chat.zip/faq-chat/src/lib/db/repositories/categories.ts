import { getDb, newId, nowIso } from "@/lib/db/client";

export type Category = {
  id: string;
  name: string;
  description: string | null;
  status: "ATIVA" | "INATIVA";
  createdAt: string;
  updatedAt: string;
};

function mapRow(row: any): Category {
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

export function listCategories(opts: { onlyActive?: boolean } = {}): Category[] {
  const db = getDb();
  const rows = opts.onlyActive
    ? db.prepare("SELECT * FROM categories WHERE status = 'ATIVA' ORDER BY name").all()
    : db.prepare("SELECT * FROM categories ORDER BY name").all();
  return rows.map(mapRow);
}

export function getCategoryById(id: string): Category | null {
  const db = getDb();
  const row = db.prepare("SELECT * FROM categories WHERE id = ?").get(id);
  return row ? mapRow(row) : null;
}

export function createCategory(input: { name: string; description?: string }): Category {
  const db = getDb();
  const id = newId();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO categories (id, name, description, status, created_at, updated_at)
     VALUES (?, ?, ?, 'ATIVA', ?, ?)`
  ).run(id, input.name, input.description ?? "", ts, ts);
  return getCategoryById(id)!;
}

export function updateCategory(id: string, input: { name: string; description?: string }): Category {
  const db = getDb();
  db.prepare("UPDATE categories SET name = ?, description = ?, updated_at = ? WHERE id = ?").run(
    input.name,
    input.description ?? "",
    nowIso(),
    id
  );
  return getCategoryById(id)!;
}

export function setCategoryStatus(id: string, status: "ATIVA" | "INATIVA") {
  const db = getDb();
  db.prepare("UPDATE categories SET status = ?, updated_at = ? WHERE id = ?").run(status, nowIso(), id);
}
