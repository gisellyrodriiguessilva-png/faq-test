import { getDb, newId, nowIso } from "@/lib/db/client";
import { normalizeForMatching } from "@/lib/search/normalize";

export type FaqStatus = "RASCUNHO" | "PUBLICADO" | "INATIVO";

export type RelatedLink = {
  id: string;
  title: string;
  url: string;
  openInNewTab: boolean;
  displayOrder: number;
};

export type FaqContent = {
  id: string;
  mainQuestion: string;
  mainQuestionNormalized: string;
  approvedAnswer: string;
  categoryId: string;
  responsibleSector: string | null;
  internalNotes: string | null;
  status: FaqStatus;
  createdBy: string;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
  viewCount: number;
  positiveRatings: number;
  negativeRatings: number;
  sourceUnansweredId: string | null;
  alternativeQuestions: string[];
  keywords: string[];
  relatedLinks: RelatedLink[];
};

function mapFaqRow(row: any): Omit<FaqContent, "alternativeQuestions" | "keywords" | "relatedLinks"> {
  return {
    id: row.id,
    mainQuestion: row.main_question,
    mainQuestionNormalized: row.main_question_normalized,
    approvedAnswer: row.approved_answer,
    categoryId: row.category_id,
    responsibleSector: row.responsible_sector,
    internalNotes: row.internal_notes,
    status: row.status,
    createdBy: row.created_by,
    updatedBy: row.updated_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    viewCount: row.view_count,
    positiveRatings: row.positive_ratings,
    negativeRatings: row.negative_ratings,
    sourceUnansweredId: row.source_unanswered_id,
  };
}

function attachRelations(db: ReturnType<typeof getDb>, base: ReturnType<typeof mapFaqRow>): FaqContent {
  const alternativeQuestions = (
    db.prepare("SELECT text FROM alternative_questions WHERE faq_id = ?").all(base.id) as any[]
  ).map((r) => r.text as string);

  const keywords = (
    db.prepare("SELECT term FROM keywords WHERE faq_id = ?").all(base.id) as any[]
  ).map((r) => r.term as string);

  const relatedLinks = (
    db
      .prepare("SELECT * FROM related_links WHERE faq_id = ? ORDER BY display_order")
      .all(base.id) as any[]
  ).map((r) => ({
    id: r.id,
    title: r.title,
    url: r.url,
    openInNewTab: !!r.open_in_new_tab,
    displayOrder: r.display_order,
  })) as RelatedLink[];

  return { ...base, alternativeQuestions, keywords, relatedLinks };
}

export function getFaqById(id: string): FaqContent | null {
  const db = getDb();
  const row = db.prepare("SELECT * FROM faq_contents WHERE id = ?").get(id);
  if (!row) return null;
  return attachRelations(db, mapFaqRow(row));
}

export function listFaqs(filters: { status?: FaqStatus; categoryId?: string; search?: string } = {}): FaqContent[] {
  const db = getDb();
  const clauses: string[] = [];
  const params: any[] = [];

  if (filters.status) {
    clauses.push("status = ?");
    params.push(filters.status);
  }
  if (filters.categoryId) {
    clauses.push("category_id = ?");
    params.push(filters.categoryId);
  }
  if (filters.search) {
    clauses.push("(main_question LIKE ? OR approved_answer LIKE ?)");
    const like = `%${filters.search}%`;
    params.push(like, like);
  }

  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
  const rows = db.prepare(`SELECT * FROM faq_contents ${where} ORDER BY updated_at DESC`).all(...params);
  return rows.map((row) => attachRelations(db, mapFaqRow(row)));
}

/** Usado pelo motor de busca: somente conteúdos publicados. */
export function listPublishedFaqs(): FaqContent[] {
  return listFaqs({ status: "PUBLICADO" });
}

function replaceChildRows(
  db: ReturnType<typeof getDb>,
  faqId: string,
  alternativeQuestions: string[],
  keywords: string[],
  relatedLinks: { title: string; url: string; openInNewTab: boolean }[]
) {
  db.prepare("DELETE FROM alternative_questions WHERE faq_id = ?").run(faqId);
  db.prepare("DELETE FROM keywords WHERE faq_id = ?").run(faqId);
  db.prepare("DELETE FROM related_links WHERE faq_id = ?").run(faqId);

  const insertAlt = db.prepare(
    "INSERT INTO alternative_questions (id, faq_id, text, text_normalized) VALUES (?, ?, ?, ?)"
  );
  for (const text of alternativeQuestions) {
    if (!text.trim()) continue;
    insertAlt.run(newId(), faqId, text, normalizeForMatching(text));
  }

  const insertKw = db.prepare("INSERT INTO keywords (id, faq_id, term, term_normalized) VALUES (?, ?, ?, ?)");
  for (const term of keywords) {
    if (!term.trim()) continue;
    insertKw.run(newId(), faqId, term, normalizeForMatching(term));
  }

  const insertLink = db.prepare(
    "INSERT INTO related_links (id, faq_id, title, url, open_in_new_tab, display_order) VALUES (?, ?, ?, ?, ?, ?)"
  );
  relatedLinks.forEach((link, index) => {
    insertLink.run(newId(), faqId, link.title, link.url, link.openInNewTab ? 1 : 0, index);
  });
}

function logChange(
  db: ReturnType<typeof getDb>,
  faqId: string,
  adminId: string,
  actionType: string,
  changedField?: string,
  oldValue?: string,
  newValue?: string
) {
  db.prepare(
    `INSERT INTO change_log (id, faq_id, admin_id, action_type, changed_field, old_value, new_value, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(newId(), faqId, adminId, actionType, changedField ?? null, oldValue ?? null, newValue ?? null, nowIso());
}

export type FaqInput = {
  mainQuestion: string;
  approvedAnswer: string;
  categoryId: string;
  responsibleSector?: string;
  internalNotes?: string;
  alternativeQuestions: string[];
  keywords: string[];
  relatedLinks: { title: string; url: string; openInNewTab: boolean }[];
};

export function createFaq(input: FaqInput, adminId: string, sourceUnansweredId?: string): FaqContent {
  const db = getDb();
  const id = newId();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO faq_contents
      (id, main_question, main_question_normalized, approved_answer, category_id, responsible_sector,
       internal_notes, status, created_by, updated_by, created_at, updated_at, source_unanswered_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'RASCUNHO', ?, ?, ?, ?, ?)`
  ).run(
    id,
    input.mainQuestion,
    normalizeForMatching(input.mainQuestion),
    input.approvedAnswer,
    input.categoryId,
    input.responsibleSector ?? "",
    input.internalNotes ?? "",
    adminId,
    adminId,
    ts,
    ts,
    sourceUnansweredId ?? null
  );
  replaceChildRows(db, id, input.alternativeQuestions, input.keywords, input.relatedLinks);
  logChange(db, id, adminId, "CRIACAO");
  return getFaqById(id)!;
}

export function updateFaq(id: string, input: FaqInput, adminId: string): FaqContent {
  const db = getDb();
  const before = getFaqById(id);
  db.prepare(
    `UPDATE faq_contents
     SET main_question = ?, main_question_normalized = ?, approved_answer = ?, category_id = ?,
         responsible_sector = ?, internal_notes = ?, updated_by = ?, updated_at = ?
     WHERE id = ?`
  ).run(
    input.mainQuestion,
    normalizeForMatching(input.mainQuestion),
    input.approvedAnswer,
    input.categoryId,
    input.responsibleSector ?? "",
    input.internalNotes ?? "",
    adminId,
    nowIso(),
    id
  );
  replaceChildRows(db, id, input.alternativeQuestions, input.keywords, input.relatedLinks);
  logChange(
    db,
    id,
    adminId,
    "EDICAO",
    "conteudo",
    before?.approvedAnswer?.slice(0, 200),
    input.approvedAnswer.slice(0, 200)
  );
  return getFaqById(id)!;
}

export function setFaqStatus(id: string, status: FaqStatus, adminId: string): FaqContent {
  const db = getDb();
  const before = getFaqById(id);
  db.prepare("UPDATE faq_contents SET status = ?, updated_by = ?, updated_at = ? WHERE id = ?").run(
    status,
    adminId,
    nowIso(),
    id
  );
  const actionType =
    status === "PUBLICADO" ? "PUBLICACAO" : status === "INATIVO" ? "DESATIVACAO" : "REATIVACAO";
  logChange(db, id, adminId, actionType, "status", before?.status, status);
  return getFaqById(id)!;
}

export function deleteFaq(id: string, adminId: string) {
  const db = getDb();
  logChange(db, id, adminId, "EXCLUSAO");
  db.prepare("DELETE FROM faq_contents WHERE id = ?").run(id);
}

export function duplicateFaq(id: string, adminId: string): FaqContent | null {
  const original = getFaqById(id);
  if (!original) return null;
  return createFaq(
    {
      mainQuestion: `${original.mainQuestion} (cópia)`,
      approvedAnswer: original.approvedAnswer,
      categoryId: original.categoryId,
      responsibleSector: original.responsibleSector ?? "",
      internalNotes: original.internalNotes ?? "",
      alternativeQuestions: original.alternativeQuestions,
      keywords: original.keywords,
      relatedLinks: original.relatedLinks.map((l) => ({ title: l.title, url: l.url, openInNewTab: l.openInNewTab })),
    },
    adminId
  );
}

export function incrementViewCount(id: string) {
  const db = getDb();
  db.prepare("UPDATE faq_contents SET view_count = view_count + 1 WHERE id = ?").run(id);
}

export function incrementRatingCount(id: string, isPositive: boolean) {
  const db = getDb();
  const column = isPositive ? "positive_ratings" : "negative_ratings";
  db.prepare(`UPDATE faq_contents SET ${column} = ${column} + 1 WHERE id = ?`).run(id);
}

export function getChangeLog(faqId: string) {
  const db = getDb();
  return db
    .prepare("SELECT * FROM change_log WHERE faq_id = ? ORDER BY created_at DESC")
    .all(faqId) as any[];
}

/** Checagem simples de possível duplicidade ao salvar (usada antes de criar/editar). */
export function findPossibleDuplicates(mainQuestion: string, excludeId?: string): FaqContent[] {
  const normalized = normalizeForMatching(mainQuestion);
  const words = normalized.split(" ").filter(Boolean);
  if (words.length === 0) return [];

  const all = listFaqs().filter((f) => f.id !== excludeId);
  return all.filter((f) => {
    const targetWords = new Set(f.mainQuestionNormalized.split(" "));
    const overlap = words.filter((w) => targetWords.has(w)).length;
    const ratio = overlap / Math.max(words.length, targetWords.size);
    return ratio >= 0.6;
  });
}
