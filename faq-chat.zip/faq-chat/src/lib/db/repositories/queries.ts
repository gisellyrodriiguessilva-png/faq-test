import { getDb, newId, nowIso } from "@/lib/db/client";
import type { ConfidenceLevel } from "@/lib/search/config";

export type QueryLog = {
  id: string;
  originalQuestion: string;
  normalizedQuestion: string;
  selectedFaqId: string | null;
  confidenceScore: number;
  resultType: ConfidenceLevel;
  createdAt: string;
};

export function logQuery(input: {
  originalQuestion: string;
  normalizedQuestion: string;
  selectedFaqId: string | null;
  confidenceScore: number;
  resultType: ConfidenceLevel;
}): QueryLog {
  const db = getDb();
  const id = newId();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO queries (id, original_question, normalized_question, selected_faq_id, confidence_score, result_type, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(id, input.originalQuestion, input.normalizedQuestion, input.selectedFaqId, input.confidenceScore, input.resultType, ts);
  return {
    id,
    originalQuestion: input.originalQuestion,
    normalizedQuestion: input.normalizedQuestion,
    selectedFaqId: input.selectedFaqId,
    confidenceScore: input.confidenceScore,
    resultType: input.resultType,
    createdAt: ts,
  };
}

export function getQueryById(id: string): QueryLog | null {
  const db = getDb();
  const row = db.prepare("SELECT * FROM queries WHERE id = ?").get(id) as any;
  if (!row) return null;
  return {
    id: row.id,
    originalQuestion: row.original_question,
    normalizedQuestion: row.normalized_question,
    selectedFaqId: row.selected_faq_id,
    confidenceScore: row.confidence_score,
    resultType: row.result_type,
    createdAt: row.created_at,
  };
}

export function countQueriesByResultType(): Record<ConfidenceLevel, number> {
  const db = getDb();
  const rows = db.prepare("SELECT result_type, COUNT(*) as c FROM queries GROUP BY result_type").all() as any[];
  const out: Record<string, number> = { ALTA: 0, MEDIA: 0, BAIXA: 0 };
  for (const r of rows) out[r.result_type] = r.c;
  return out as Record<ConfidenceLevel, number>;
}

export function mostConsultedFaqs(limit = 5) {
  const db = getDb();
  return db
    .prepare(
      `SELECT f.id, f.main_question, COUNT(q.id) as total
       FROM queries q JOIN faq_contents f ON f.id = q.selected_faq_id
       GROUP BY f.id ORDER BY total DESC LIMIT ?`
    )
    .all(limit) as any[];
}
