import { getDb, newId, nowIso } from "@/lib/db/client";

export type UnansweredStatus = "PENDENTE" | "EM_ANALISE" | "TRANSFORMADA" | "DUPLICADA" | "DESCARTADA" | "RESOLVIDA";

export type UnansweredQuestion = {
  id: string;
  originalQuestion: string;
  normalizedQuestion: string;
  occurrenceCount: number;
  bestScoreFound: number;
  status: UnansweredStatus;
  responsibleAdminId: string | null;
  adminNote: string | null;
  createdFaqId: string | null;
  firstOccurredAt: string;
  lastOccurredAt: string;
};

function mapRow(row: any): UnansweredQuestion {
  return {
    id: row.id,
    originalQuestion: row.original_question,
    normalizedQuestion: row.normalized_question,
    occurrenceCount: row.occurrence_count,
    bestScoreFound: row.best_score_found,
    status: row.status,
    responsibleAdminId: row.responsible_admin_id,
    adminNote: row.admin_note,
    createdFaqId: row.created_faq_id,
    firstOccurredAt: row.first_occurred_at,
    lastOccurredAt: row.last_occurred_at,
  };
}

export function listUnanswered(status?: UnansweredStatus): UnansweredQuestion[] {
  const db = getDb();
  const rows = status
    ? db.prepare("SELECT * FROM unanswered_questions WHERE status = ? ORDER BY occurrence_count DESC").all(status)
    : db.prepare("SELECT * FROM unanswered_questions ORDER BY last_occurred_at DESC").all();
  return rows.map(mapRow);
}

export function getUnansweredById(id: string): UnansweredQuestion | null {
  const db = getDb();
  const row = db.prepare("SELECT * FROM unanswered_questions WHERE id = ?").get(id);
  return row ? mapRow(row) : null;
}

/** Registra uma dúvida não respondida, agrupando com uma existente quando a normalização bate. */
export function recordUnanswered(originalQuestion: string, normalizedQuestion: string, scoreFound: number) {
  const db = getDb();
  const existing = db
    .prepare(
      "SELECT * FROM unanswered_questions WHERE normalized_question = ? AND status NOT IN ('TRANSFORMADA', 'DESCARTADA', 'RESOLVIDA')"
    )
    .get(normalizedQuestion) as any;

  if (existing) {
    db.prepare(
      `UPDATE unanswered_questions
       SET occurrence_count = occurrence_count + 1, last_occurred_at = ?, best_score_found = MAX(best_score_found, ?)
       WHERE id = ?`
    ).run(nowIso(), scoreFound, existing.id);
    return mapRow({ ...existing, occurrence_count: existing.occurrence_count + 1 });
  }

  const id = newId();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO unanswered_questions
      (id, original_question, normalized_question, occurrence_count, best_score_found, status, first_occurred_at, last_occurred_at)
     VALUES (?, ?, ?, 1, ?, 'PENDENTE', ?, ?)`
  ).run(id, originalQuestion, normalizedQuestion, scoreFound, ts, ts);
  return getUnansweredById(id)!;
}

export function updateUnansweredStatus(
  id: string,
  status: UnansweredStatus,
  adminId: string,
  adminNote?: string
) {
  const db = getDb();
  db.prepare(
    "UPDATE unanswered_questions SET status = ?, responsible_admin_id = ?, admin_note = ? WHERE id = ?"
  ).run(status, adminId, adminNote ?? "", id);
}

export function linkCreatedFaq(id: string, faqId: string) {
  const db = getDb();
  db.prepare("UPDATE unanswered_questions SET created_faq_id = ?, status = 'TRANSFORMADA' WHERE id = ?").run(
    faqId,
    id
  );
}
