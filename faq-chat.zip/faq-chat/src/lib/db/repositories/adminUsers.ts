import { getDb, newId, nowIso } from "@/lib/db/client";

export type AdminUser = {
  id: string;
  name: string;
  username: string;
  passwordHash: string;
  status: "ATIVO" | "INATIVO";
  createdAt: string;
  updatedAt: string;
  lastLoginAt: string | null;
};

function mapRow(row: any): AdminUser {
  return {
    id: row.id,
    name: row.name,
    username: row.username,
    passwordHash: row.password_hash,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    lastLoginAt: row.last_login_at,
  };
}

export function findAdminByUsername(username: string): AdminUser | null {
  const db = getDb();
  const row = db
    .prepare("SELECT * FROM admin_users WHERE username = ? AND status = 'ATIVO'")
    .get(username);
  return row ? mapRow(row) : null;
}

export function findAdminById(id: string): AdminUser | null {
  const db = getDb();
  const row = db.prepare("SELECT * FROM admin_users WHERE id = ?").get(id);
  return row ? mapRow(row) : null;
}

export function createAdminUser(input: { name: string; username: string; passwordHash: string }): AdminUser {
  const db = getDb();
  const id = newId();
  const ts = nowIso();
  db.prepare(
    `INSERT INTO admin_users (id, name, username, password_hash, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, 'ATIVO', ?, ?)`
  ).run(id, input.name, input.username, input.passwordHash, ts, ts);
  return findAdminById(id)!;
}

export function touchLastLogin(id: string) {
  const db = getDb();
  db.prepare("UPDATE admin_users SET last_login_at = ? WHERE id = ?").run(nowIso(), id);
}

export function countAdmins(): number {
  const db = getDb();
  const row = db.prepare("SELECT COUNT(*) as c FROM admin_users").get() as any;
  return row.c as number;
}
