import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";

// Camada única de acesso ao SQLite (via módulo nativo node:sqlite, sem dependências
// externas de compilação). Pensada para ser a ÚNICA parte do projeto que conhece o
// dialeto do banco: trocar para PostgreSQL no futuro significa reescrever este
// arquivo e os arquivos em /repositories, sem tocar em Server Actions ou UI.

declare global {
  var __faqDb: DatabaseSync | undefined;
}

function resolveDbPath() {
  const configured = process.env.DATABASE_FILE || "./data/faq-chat.db";
  return path.isAbsolute(configured) ? configured : path.join(process.cwd(), configured);
}

function createConnection(): DatabaseSync {
  const dbPath = resolveDbPath();
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });

  const db = new DatabaseSync(dbPath);
  db.exec("PRAGMA foreign_keys = ON;");
  db.exec("PRAGMA journal_mode = WAL;");

  const schemaPath = path.join(process.cwd(), "src/lib/db/schema.sql");
  const schema = fs.readFileSync(schemaPath, "utf-8");
  db.exec(schema);

  return db;
}

// Reaproveita a conexão entre hot-reloads do Next.js em desenvolvimento.
export function getDb(): DatabaseSync {
  if (!global.__faqDb) {
    global.__faqDb = createConnection();
  }
  return global.__faqDb;
}

export function newId(): string {
  return crypto.randomUUID();
}

export function nowIso(): string {
  return new Date().toISOString();
}
