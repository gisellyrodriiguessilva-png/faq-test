import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  {
    // A camada de acesso a dados (node:sqlite) trabalha com linhas não tipadas
    // por natureza (.get()/.all() retornam registros genéricos); mapeamos
    // manualmente para tipos de domínio logo em seguida, então `any` aqui é
    // intencional e não um descuido de tipagem.
    files: ["src/lib/db/repositories/**/*.ts", "src/app/**/page.tsx", "tests/**/*.ts"],
    rules: {
      "@typescript-eslint/no-explicit-any": "off",
    },
  },
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;
