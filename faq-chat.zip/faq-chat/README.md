# FAQ Chat Interno

Assistente de dúvidas em formato de chat para uma equipe administrativa. O chat localiza,
por similaridade textual, a resposta **já cadastrada e aprovada** que melhor corresponde à
pergunta do usuário — nunca gera, reformula ou complementa texto novo.

## Objetivo do projeto

Reduzir o tempo gasto respondendo manualmente às mesmas dúvidas recorrentes (pagamentos,
fornecedores, documentos, planilhas, sistemas, processos internos), permitindo que a própria
equipe administrativa cadastre e mantenha essa base de respostas.

## Escopo deste MVP

**Incluído:** chat público sem login; painel administrativo com login por usuário/senha;
CRUD completo de categorias e conteúdos de FAQ (pergunta principal, perguntas alternativas,
palavras-chave, links relacionados, observações internas, status Rascunho/Publicado/Inativo);
motor de busca híbrido com score de confiança; fila de "perguntas não respondidas" com
agrupamento por ocorrência e conversão em novo FAQ; avaliações (👍/👎 + comentário);
dashboard com métricas simples; histórico de alterações por conteúdo; verificação de
possíveis duplicidades ao cadastrar.

**Fora deste MVP** (ver seção "Evoluções futuras"): login de usuário comum, Microsoft Entra ID,
IA generativa/busca semântica, import/export por planilha, integrações com Teams/SharePoint,
app mobile, relatórios avançados com gráficos.

## Tecnologias

- **Next.js 16** (App Router) + **React 19** + **TypeScript**
- **Tailwind CSS 4**
- **`node:sqlite`** (módulo nativo do Node 22) como banco de dados em desenvolvimento —
  ver nota abaixo sobre a troca do Prisma
- **Zod** para validação de formulários e Server Actions
- **Fuse.js** + coeficiente de Dice (sobreposição de palavras) para busca aproximada
- **bcryptjs** para hash de senha, **iron-session** para sessão de administrador
- **Node test runner** (`node:test`) + `tsx` para os testes automatizados

### Nota sobre a escolha do banco de dados

O plano original previa Prisma ORM. Prisma precisa baixar binários de engine de
`binaries.prisma.sh`, e alternativas como `better-sqlite3` exigem compilar um módulo nativo
contra os headers do Node — nenhum dos dois é viável em ambientes com acesso de rede restrito
apenas a registries de pacotes (npm). Por isso a persistência usa o módulo **nativo**
`node:sqlite` (estável a partir do Node 22, ainda marcado como experimental pelo runtime),
com uma camada de acesso a dados própria e isolada em `src/lib/db/`. Essa é a única parte do
projeto que conhece o dialeto SQL; migrar para PostgreSQL no futuro significa reescrever
`src/lib/db/client.ts` e os arquivos em `src/lib/db/repositories/`, sem tocar em Server
Actions, páginas ou componentes.

## Arquitetura

Monolito Next.js full stack (sem API separada):

```
src/
  app/
    page.tsx                  → chat público (rota "/")
    admin/
      login/                  → login (fora do grupo protegido)
      (protected)/            → grupo de rotas com guarda de autenticação
        dashboard/
        knowledge-base/       → listagem, novo, editar, criar a partir de não respondida
        categories/
        unanswered/
        ratings/
  lib/
    db/                       → client node:sqlite + schema.sql + repositories/
    search/                   → normalize.ts, engine.ts, config.ts (limites de confiança)
    auth/                     → sessão (iron-session), hash de senha, guard de admin
    validation/               → schemas Zod compartilhados
  actions/                    → Server Actions (auth, categories, faqContents, chat, ratings, unanswered)
  components/
    chat/                     → ChatWidget (client component)
    admin/                    → FaqForm, ConfirmSubmitButton
  middleware.ts                → primeira barreira de proteção de /admin/*
scripts/
  seed.ts                     → dados de demonstração
tests/
  main-flows.test.ts          → fluxos principais (node:test)
```

## Modelo de dados

Ver `src/lib/db/schema.sql` para o schema completo. Entidades principais: `admin_users`,
`categories`, `faq_contents`, `alternative_questions`, `keywords`, `related_links`, `queries`
(log de cada pergunta feita no chat), `unanswered_questions`, `ratings`, `change_log`.

## Estratégia de busca

Pipeline em `src/lib/search/engine.ts`, nesta ordem de prioridade:

1. Correspondência exata com a pergunta principal
2. Correspondência exata com uma pergunta alternativa
3. Presença de palavras-chave cadastradas
4. Similaridade aproximada — combina duas técnicas, usando a maior pontuação entre elas:
   - **Sobreposição de palavras** (coeficiente de Dice) entre a pergunta e o conteúdo cadastrado — lida bem com paráfrases ("como faço para pagar um fornecedor" vs "como pagar um fornecedor")
   - **Fuse.js** (similaridade de caracteres) — pega erros de digitação e pequenas variações

Cada técnica produz um score de 0 a 1; o maior score de cada conteúdo é comparado aos
limites de confiança abaixo.

### Limites de confiança

Centralizados em `src/lib/search/config.ts` (`CONFIDENCE_THRESHOLDS`):

- **Alta** (score ≥ 0.75): exibe a resposta diretamente
- **Média** (0.45 ≤ score < 0.75): mostra até 3 perguntas relacionadas para o usuário escolher
- **Baixa** (score < 0.45): mensagem de "não encontrei resposta segura" + registro automático
  como pergunta não respondida

Ajuste esses números apenas nesse arquivo — nenhuma outra parte do código deve ter esses
valores fixos.

## Instalação e execução

### Pré-requisitos

- Node.js 22 ou superior (necessário para `node:sqlite`)

### Passos

```bash
npm install
cp .env.example .env
```

Edite o `.env`:

- `SESSION_SECRET`: gere com `openssl rand -base64 32` (mínimo 32 caracteres — a aplicação
  falha ao iniciar sem isso, de propósito)
- `SEED_ADMIN_USERNAME` / `SEED_ADMIN_PASSWORD` / `SEED_ADMIN_NAME`: credenciais do primeiro
  administrador (usadas apenas pelo script de seed, nunca fixe uma senha real no código)

### Banco de dados

Não há migrações separadas: o schema (`src/lib/db/schema.sql`) é aplicado automaticamente
(`CREATE TABLE IF NOT EXISTS ...`) na primeira conexão. Para popular com dados de
demonstração:

```bash
npm run seed
```

Isso cria o primeiro administrador (a partir do `.env`), categorias, 5 FAQs publicadas com
perguntas alternativas e palavras-chave, algumas avaliações e duas perguntas não respondidas
de exemplo.

### Desenvolvimento

```bash
npm run dev
```

Chat público em `http://localhost:3000/`, painel administrativo em
`http://localhost:3000/admin/login`.

### Testes

```bash
npm test
```

Cobre: hash de senha, bloqueio de rota administrativa sem autenticação, rascunho não
aparece no chat, publicação libera busca exata/alternativa/palavra-chave/aproximada,
resposta exibida idêntica à cadastrada, conteúdo inativo some da busca, agrupamento de
perguntas não respondidas por ocorrência, avaliações positivas e negativas.

### Build de produção

```bash
npm run build
npm start
```

### Lint e checagem de tipos

```bash
npm run lint
npm run typecheck
```

## Como usar o painel administrativo

- **Cadastrar perguntas**: Base de conhecimento → Novo conteúdo. Preencha pergunta principal,
  resposta aprovada, categoria, e opcionalmente perguntas alternativas, palavras-chave, links
  relacionados e observações internas (essas últimas nunca aparecem no chat).
- **Publicar uma resposta**: o conteúdo é salvo como Rascunho por padrão; clique em
  "Publicar" na listagem ou na página do conteúdo para que ele passe a aparecer no chat.
- **Tratar perguntas não respondidas**: em "Perguntas não respondidas", ajuste o status
  (Pendente, Em análise, Duplicada, Descartada, Resolvida) e, quando fizer sentido, clique em
  "Criar resposta" para abrir o formulário de cadastro já com o texto da dúvida preenchido.
  Depois de salvo, o item fica marcado como "Transformada em FAQ" e só aparece no chat quando
  você publicar o conteúdo criado.
- **Ajustar os limites de confiança**: edite as constantes em `src/lib/search/config.ts`.
- **Desativar um conteúdo**: botão "Desativar" na listagem ou na página do conteúdo — o
  registro continua salvo, mas some das buscas até ser reativado.
- **Criar categorias**: página "Categorias", acessível pelo link no topo da Base de
  conhecimento.
- **Verificar avaliações negativas**: página "Avaliações" lista todas, com comentário quando
  informado; o dashboard também mostra as mais recentes.

## Limitações da versão inicial

- Usuário comum do chat não possui login (aplicação pensada para rodar apenas no ambiente
  interno da empresa).
- Banco de dados em arquivo único (SQLite via `node:sqlite`); adequado para o volume de uso
  de uma equipe administrativa, mas não para alta concorrência.
- Motor de busca é heurístico (palavras-chave, sobreposição de palavras e similaridade de
  caracteres) — não usa IA generativa nem embeddings, por design.
- Sem exportação/importação de planilhas nesta versão.

## Evoluções futuras (apenas documentadas, não implementadas)

Autenticação para usuários comuns; integração com Microsoft Entra ID; importação/exportação
por CSV; integração com SharePoint e Teams; embeddings e busca semântica com IA; anexos;
permissões por setor; múltiplas bases de conhecimento; aprovação em duas etapas; notificações
para administradores; relatórios avançados com gráficos; API pública para integrações;
histórico de conversa por usuário.
