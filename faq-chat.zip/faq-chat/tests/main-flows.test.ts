import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

// Usa um arquivo de banco isolado para os testes, para não misturar com dados de desenvolvimento.
const TEST_DB = path.join(process.cwd(), "data", "test-faq-chat.db");
process.env.DATABASE_FILE = TEST_DB;
process.env.SESSION_SECRET = "test-secret-please-ignore-1234567890123456";

// Os módulos da aplicação são carregados dinamicamente dentro do hook `before` (assíncrono),
// pois precisam ser importados DEPOIS de definir as variáveis de ambiente acima — o cliente
// do banco (src/lib/db/client.ts) lê DATABASE_FILE na primeira conexão. Evitamos top-level
// await para manter compatibilidade com a saída CommonJS que o tsx usa neste projeto.
type Mods = {
  hashPassword: typeof import("../src/lib/auth/password").hashPassword;
  verifyPassword: typeof import("../src/lib/auth/password").verifyPassword;
  createAdminUser: typeof import("../src/lib/db/repositories/adminUsers").createAdminUser;
  findAdminByUsername: typeof import("../src/lib/db/repositories/adminUsers").findAdminByUsername;
  createCategory: typeof import("../src/lib/db/repositories/categories").createCategory;
  createFaq: typeof import("../src/lib/db/repositories/faqContents").createFaq;
  setFaqStatus: typeof import("../src/lib/db/repositories/faqContents").setFaqStatus;
  deleteFaq: typeof import("../src/lib/db/repositories/faqContents").deleteFaq;
  getFaqById: typeof import("../src/lib/db/repositories/faqContents").getFaqById;
  searchFaqs: typeof import("../src/lib/search/engine").searchFaqs;
  recordUnanswered: typeof import("../src/lib/db/repositories/unanswered").recordUnanswered;
  listUnanswered: typeof import("../src/lib/db/repositories/unanswered").listUnanswered;
  createRating: typeof import("../src/lib/db/repositories/ratings").createRating;
  countRatings: typeof import("../src/lib/db/repositories/ratings").countRatings;
  logQuery: typeof import("../src/lib/db/repositories/queries").logQuery;
  getDb: typeof import("../src/lib/db/client").getDb;
};

let mods: Mods;
let adminId: string;
let categoryId: string;

before(async () => {
  for (const ext of ["", "-wal", "-shm"]) {
    const f = TEST_DB + ext;
    if (fs.existsSync(f)) fs.unlinkSync(f);
  }

  mods = {
    ...(await import("../src/lib/auth/password")),
    ...(await import("../src/lib/db/repositories/adminUsers")),
    ...(await import("../src/lib/db/repositories/categories")),
    ...(await import("../src/lib/db/repositories/faqContents")),
    ...(await import("../src/lib/search/engine")),
    ...(await import("../src/lib/db/repositories/unanswered")),
    ...(await import("../src/lib/db/repositories/ratings")),
    ...(await import("../src/lib/db/repositories/queries")),
    ...(await import("../src/lib/db/client")),
  } as Mods;
});

after(() => {
  mods.getDb().close();
  for (const ext of ["", "-wal", "-shm"]) {
    const f = TEST_DB + ext;
    if (fs.existsSync(f)) fs.unlinkSync(f);
  }
});

test("cria administrador com senha em hash (nunca texto puro)", async () => {
  const hash = await mods.hashPassword("MinhaSenh@123");
  assert.notEqual(hash, "MinhaSenh@123");
  const admin = mods.createAdminUser({ name: "Admin Teste", username: "admin.teste", passwordHash: hash });
  adminId = admin.id;
  assert.ok(await mods.verifyPassword("MinhaSenh@123", admin.passwordHash));
  assert.equal(await mods.verifyPassword("senha-errada", admin.passwordHash), false);
});

test("login falha para usuário inexistente", () => {
  assert.equal(mods.findAdminByUsername("nao-existe"), null);
});

test("cria categoria", () => {
  const category = mods.createCategory({ name: "Pagamentos Teste" });
  categoryId = category.id;
  assert.equal(category.status, "ATIVA");
});

test("cria FAQ como rascunho e não aparece na busca pública", () => {
  const faq = mods.createFaq(
    {
      mainQuestion: "Como solicitar reembolso de despesas de viagem?",
      approvedAnswer: "Envie a nota fiscal e o formulário de reembolso ao financeiro.",
      categoryId,
      alternativeQuestions: ["Como pedir reembolso de viagem?"],
      keywords: ["reembolso", "viagem"],
      relatedLinks: [],
    },
    adminId
  );
  assert.equal(faq.status, "RASCUNHO");

  const result = mods.searchFaqs("Como solicitar reembolso de despesas de viagem?");
  assert.equal(result.confidence, "BAIXA");
  assert.equal(result.answer, null);

  // Publica e agora deve ser encontrado com alta confiança (busca exata).
  mods.setFaqStatus(faq.id, "PUBLICADO", adminId);
  const afterPublish = mods.searchFaqs("Como solicitar reembolso de despesas de viagem?");
  assert.equal(afterPublish.confidence, "ALTA");
  assert.equal(afterPublish.answer?.id, faq.id);

  // A resposta exibida deve ser EXATAMENTE a cadastrada, sem alterações.
  assert.equal(afterPublish.answer?.approvedAnswer, "Envie a nota fiscal e o formulário de reembolso ao financeiro.");
});

test("busca por pergunta alternativa (correspondência exata)", () => {
  const result = mods.searchFaqs("Como pedir reembolso de viagem?");
  assert.equal(result.confidence, "ALTA");
});

test("busca por palavra-chave e por similaridade aproximada", () => {
  const byKeyword = mods.searchFaqs("dúvida sobre reembolso");
  assert.notEqual(byKeyword.confidence, "BAIXA");

  const byFuzzy = mods.searchFaqs("como peco reembolso da viagem");
  assert.notEqual(byFuzzy.confidence, "BAIXA");
});

test("conteúdo inativo não aparece na busca", () => {
  const faq = mods.createFaq(
    {
      mainQuestion: "Pergunta temporária de teste de inativação",
      approvedAnswer: "Resposta de teste.",
      categoryId,
      alternativeQuestions: [],
      keywords: [],
      relatedLinks: [],
    },
    adminId
  );
  mods.setFaqStatus(faq.id, "PUBLICADO", adminId);
  assert.equal(mods.searchFaqs("Pergunta temporária de teste de inativação").confidence, "ALTA");

  mods.setFaqStatus(faq.id, "INATIVO", adminId);
  assert.equal(mods.searchFaqs("Pergunta temporária de teste de inativação").confidence, "BAIXA");

  mods.deleteFaq(faq.id, adminId);
  assert.equal(mods.getFaqById(faq.id), null);
});

test("pergunta sem resposta segura é registrada e agrupada por ocorrência", () => {
  mods.recordUnanswered("Como faço para trocar meu crachá?", "como faco para trocar meu crache", 0.1);
  mods.recordUnanswered("Como faço para trocar meu crachá?", "como faco para trocar meu crache", 0.12);

  const list = mods.listUnanswered();
  const entry = list.find((u) => u.normalizedQuestion === "como faco para trocar meu crache");
  assert.ok(entry);
  assert.equal(entry?.occurrenceCount, 2);
});

test("avaliação positiva e negativa são contabilizadas", () => {
  const faq = mods.createFaq(
    {
      mainQuestion: "Pergunta de teste para avaliação",
      approvedAnswer: "Resposta de teste para avaliação.",
      categoryId,
      alternativeQuestions: [],
      keywords: [],
      relatedLinks: [],
    },
    adminId
  );
  mods.setFaqStatus(faq.id, "PUBLICADO", adminId);

  const query = mods.logQuery({
    originalQuestion: "Pergunta de teste para avaliação",
    normalizedQuestion: "pergunta teste avaliacao",
    selectedFaqId: faq.id,
    confidenceScore: 1,
    resultType: "ALTA",
  });

  const before = mods.countRatings();
  mods.createRating({ queryId: query.id, faqId: faq.id, isPositive: true });
  mods.createRating({ queryId: query.id, faqId: faq.id, isPositive: false, comment: "Faltou um link" });
  const after = mods.countRatings();

  assert.equal(after.positive, before.positive + 1);
  assert.equal(after.negative, before.negative + 1);
});
