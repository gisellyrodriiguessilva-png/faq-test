/**
 * Popula o banco com dados de demonstração.
 * Uso: npm run seed
 *
 * As credenciais do administrador inicial vêm de variáveis de ambiente
 * (veja .env.example) — nunca fixamos uma senha real no código.
 */
import "dotenv/config";
import { getDb } from "../src/lib/db/client";
import { createAdminUser, countAdmins, findAdminByUsername } from "../src/lib/db/repositories/adminUsers";
import { createCategory, listCategories } from "../src/lib/db/repositories/categories";
import { createFaq, setFaqStatus } from "../src/lib/db/repositories/faqContents";
import { recordUnanswered } from "../src/lib/db/repositories/unanswered";
import { createRating } from "../src/lib/db/repositories/ratings";
import { logQuery } from "../src/lib/db/repositories/queries";
import { hashPassword } from "../src/lib/auth/password";

async function ensureAdmin() {
  const username = process.env.SEED_ADMIN_USERNAME || "admin";
  const password = process.env.SEED_ADMIN_PASSWORD;
  const name = process.env.SEED_ADMIN_NAME || "Administrador";

  const existing = findAdminByUsername(username);
  if (existing) {
    console.log(`Administrador "${username}" já existe, mantendo como está.`);
    return existing;
  }

  if (!password) {
    if (countAdmins() > 0) {
      console.log("Já existem administradores cadastrados; nenhum novo será criado sem SEED_ADMIN_PASSWORD.");
      return null;
    }
    throw new Error(
      "SEED_ADMIN_PASSWORD não definido no .env — defina uma senha para criar o primeiro administrador."
    );
  }

  const passwordHash = await hashPassword(password);
  const admin = createAdminUser({ name, username, passwordHash });
  console.log(`Administrador inicial "${username}" criado.`);
  return admin;
}

function ensureCategories() {
  const names = ["Pagamentos", "Fornecedores", "Documentos", "Planilhas", "Sistemas", "Processos internos"];
  const existing = listCategories();
  const byName = new Map(existing.map((c) => [c.name, c]));
  for (const name of names) {
    if (!byName.has(name)) {
      byName.set(name, createCategory({ name }));
    }
  }
  return byName;
}

async function main() {
  const admin = await ensureAdmin();
  const categories = ensureCategories();

  if (!admin) {
    console.log("Seed de conteúdo requer um administrador — encerrando aqui.");
    return;
  }

  const sampleFaqs = [
    {
      mainQuestion: "Como solicitar o pagamento de um fornecedor?",
      approvedAnswer:
        "Para solicitar o pagamento de um fornecedor:\n\n1. Acesse o sistema financeiro interno.\n2. Anexe a nota fiscal e o comprovante de entrega.\n3. Preencha o formulário de solicitação de pagamento.\n4. Envie para aprovação do setor Financeiro.\n\nO prazo médio de processamento é de 5 dias úteis.",
      category: "Pagamentos",
      alternativeQuestions: [
        "Como pagar um fornecedor?",
        "Onde envio a nota fiscal?",
        "Como faço uma solicitação de pagamento?",
        "Qual é o processo para pagamento de fornecedores?",
      ],
      keywords: ["pagamento", "fornecedor", "nota fiscal", "boleto", "financeiro"],
    },
    {
      mainQuestion: "Como cadastrar um novo fornecedor?",
      approvedAnswer:
        "Para cadastrar um novo fornecedor, envie ao setor de Compras: CNPJ, contrato social, dados bancários e uma nota fiscal de exemplo. O cadastro é validado em até 3 dias úteis.",
      category: "Fornecedores",
      alternativeQuestions: ["Como incluir um fornecedor novo?", "Preciso cadastrar um fornecedor, como faço?"],
      keywords: ["fornecedor", "cadastro", "compras"],
    },
    {
      mainQuestion: "Onde encontro a planilha de controle de horas?",
      approvedAnswer:
        "A planilha de controle de horas fica na pasta compartilhada do setor administrativo, na subpasta 'Controle de Ponto'. Peça acesso ao seu gestor caso não consiga visualizar.",
      category: "Planilhas",
      alternativeQuestions: ["Onde está a planilha de horas?", "Como acesso o controle de ponto?"],
      keywords: ["planilha", "horas", "ponto"],
    },
    {
      mainQuestion: "Como solicito acesso a um sistema interno?",
      approvedAnswer:
        "Abra um chamado no sistema de TI informando o sistema desejado e a justificativa. O acesso é liberado pelo gestor responsável em até 2 dias úteis.",
      category: "Sistemas",
      alternativeQuestions: ["Como peço acesso a um sistema?", "Preciso de acesso, o que eu faço?"],
      keywords: ["acesso", "sistema", "ti"],
    },
    {
      mainQuestion: "Quais documentos preciso para reembolso de despesas?",
      approvedAnswer:
        "Para reembolso de despesas, envie: nota fiscal ou recibo original, comprovante de pagamento e o formulário de reembolso preenchido, todos anexados no sistema financeiro.",
      category: "Documentos",
      alternativeQuestions: ["Como faço um reembolso?", "O que preciso enviar para reembolso?"],
      keywords: ["reembolso", "despesas", "documentos"],
    },
  ];

  for (const item of sampleFaqs) {
    const category = categories.get(item.category)!;
    const faq = createFaq(
      {
        mainQuestion: item.mainQuestion,
        approvedAnswer: item.approvedAnswer,
        categoryId: category.id,
        alternativeQuestions: item.alternativeQuestions,
        keywords: item.keywords,
        relatedLinks: [],
      },
      admin.id
    );
    setFaqStatus(faq.id, "PUBLICADO", admin.id);

    const query = logQuery({
      originalQuestion: item.mainQuestion,
      normalizedQuestion: faq.mainQuestionNormalized,
      selectedFaqId: faq.id,
      confidenceScore: 1,
      resultType: "ALTA",
    });
    createRating({ queryId: query.id, faqId: faq.id, isPositive: true });
  }

  recordUnanswered("Como faço para trocar meu crachá?", "como faco para trocar meu crache", 0.2);
  recordUnanswered("Qual o horário do ônibus fretado?", "qual o horario do onibus fretado", 0.15);

  console.log("Seed concluído.");
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => {
    getDb().close();
  });
